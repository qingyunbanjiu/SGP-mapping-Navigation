#!/usr/bin/env python3
import rospy
import numpy as np
import math
from nav_msgs.msg import OccupancyGrid, Path
from geometry_msgs.msg import PoseStamped, PoseWithCovarianceStamped, Twist
import tf2_ros
from tf2_geometry_msgs import do_transform_pose
from tf.transformations import euler_from_quaternion
from functions import (
    run_sgp_mapping,
    update_global_maps_from_sgp,
    is_point_valid,
    extract_water_edge_from_semantic_map,
    detect_structural_blockage_from_grid,
    extract_candidate_cross_points_in_radius,
    select_best_cross_domain_point,
    try_virtual_goal_path,
    calculate_temp_target,
    visualize_path_local_traversability1,
    retrain_sgp_and_visualize_path,
    visualize_pointcloud_surface,
)

# 其它工具类
from point_utils import Point
from utils import world_to_grid, grid_to_world

ARRIVAL_THRESHOLD = 0.1  # m, 到达目标阈值

class DStarPlannerNode:
    def __init__(self):
        rospy.init_node('dstar_planner')
        self.tf_buffer = tf2_ros.Buffer()
        tf2_ros.TransformListener(self.tf_buffer)

        # ROS topic pub/sub
        rospy.Subscriber('/sgp_global_traversability', OccupancyGrid, self.grid_cb)
        rospy.Subscriber('/move_base_simple/goal', PoseStamped, self.goal_cb)
        rospy.Subscriber('/robot_pose_ekf/odom_combined', PoseWithCovarianceStamped, self.odom_cb)
        self.path_pub = rospy.Publisher('/dstar_path', Path, queue_size=1)
        self.cmd_pub  = rospy.Publisher('/cmd_vel', Twist, queue_size=1)

        # state
        self.origin = None
        self.resolution = None
        self.trav_map = None
        self.env_map = None
        self.current_ps = None
        self.goal_ps = None
        self.original_goal_idx = None
        self.override_goal_idx = None

        rospy.loginfo("D*Lite 闭环导航节点启动")
        rospy.spin()

    def grid_cb(self, msg: OccupancyGrid):
        h, w = msg.info.height, msg.info.width
        self.origin = msg.info.origin.position
        self.resolution = msg.info.resolution
        data = np.array(msg.data).reshape((h, w)).astype(np.float32)
        data[data < 0] = np.nan  # unknown -> nan
        self.trav_map = data / 100.0
        self.env_map = np.ones_like(self.trav_map)
        self.env_map[np.isnan(data) | (data >= 100)] = 0
        # if already have goal and pose, replan
        if self.original_goal_idx is not None and self.current_ps:
            self.replan_and_publish()

    def odom_cb(self, msg: PoseWithCovarianceStamped):
        ps = PoseStamped()
        ps.header = msg.header
        ps.pose = msg.pose.pose
        self.current_ps = ps

    def goal_cb(self, msg: PoseStamped):
        try:
            trans = self.tf_buffer.lookup_transform(
                'odom_combined', msg.header.frame_id,
                rospy.Time(0), rospy.Duration(1.0))
            self.goal_ps = do_transform_pose(msg, trans)
        except Exception as e:
            rospy.logerr("Goal TF 转换失败: %s", e)
            return
        if not self.current_ps or self.trav_map is None:
            return
        # record original goal, clear override
        self.original_goal_idx = self.world2grid(self.goal_ps)
        self.override_goal_idx = None
        rospy.loginfo("接收新目标: %s", self.original_goal_idx)
        self.replan_and_publish()

    def world2grid(self, ps: PoseStamped):
        x = ps.pose.position.x - self.origin.x
        y = ps.pose.position.y - self.origin.y
        return (int(y/self.resolution), int(x/self.resolution))

    def publish_path(self, path_indices):
        path_msg = Path()
        path_msg.header.frame_id = 'odom_combined'
        path_msg.header.stamp = rospy.Time.now()
        for (i, j) in path_indices:
            ps = PoseStamped()
            ps.header = path_msg.header
            ps.pose.position.x = self.origin.x + (j + 0.5) * self.resolution
            ps.pose.position.y = self.origin.y + (i + 0.5) * self.resolution
            path_msg.poses.append(ps)
        self.path_pub.publish(path_msg)
        rospy.loginfo("发布路径: %d 点", len(path_indices))

    def replan_and_publish(self):
        if not self.current_ps or self.original_goal_idx is None:
            return
        start_idx = self.world2grid(self.current_ps)
        # select current goal: override if any, else original
        goal_idx = self.override_goal_idx if self.override_goal_idx else self.original_goal_idx

        # arrival detection
        if start_idx == goal_idx:
            if self.override_goal_idx:
                rospy.loginfo("✅ 到达跨域点 %s，恢复导航至原目标 %s", start_idx, self.original_goal_idx)
                self.override_goal_idx = None
            else:
                rospy.loginfo("✅ 已到达最终目标 %s，停止导航", goal_idx)
                self.cmd_pub.publish(Twist())
            return

        # plan path with D* Lite
        planner = DStarLite(start_idx, goal_idx, self.trav_map, self.env_map, self.resolution)
        planner.compute_shortest_path()
        path_indices = planner.extract_path()

        # —— 结构性阻碍检测与跨域触发 ——
        block_count = 0
        candidate_cross = None
        edge_pts = np.argwhere(extract_water_edge_from_semantic_map(self.env_map, self.trav_map))
        for curr, nxt in zip(path_indices[:-1], path_indices[1:]):
            is_blocked, *_ = detect_structural_blockage_from_grid(
                current_grid=curr, next_grid=nxt,
                edge_points=edge_pts,
                resolution=self.resolution,
                min_x=self.origin.x, min_y=self.origin.y
            )
            if is_blocked:
                block_count += 1
            else:
                block_count = 0
            if block_count >= 2 and not self.override_goal_idx:
                # extract candidates
                cands = extract_candidate_cross_points_in_radius(
                    current_grid=curr, edge_points=edge_pts,
                    global_envrionment_map=self.env_map,
                    resolution=self.resolution, radius=4.0
                )
                candidate_cross = select_best_cross_domain_point(
                    water_edge_mask=extract_water_edge_from_semantic_map(self.env_map, self.trav_map),
                    initial_goal_grid=self.original_goal_idx,
                    initial_start_grid=self.original_goal_idx,  # unused here
                    current_grid=curr,
                    candidate_cross_grids=cands,
                    global_traversability_map=self.trav_map,
                    global_envrionment_map=self.env_map,
                    global_normal_map=None,
                    global_mean_map=None,
                    weight_dist=1.0, weight_rough=2.0,
                    resolution=self.resolution
                )
                rospy.loginfo("�� 触发跨域阻碍，在格点 %s 选取跨域点 %s", curr, candidate_cross)
                break

        # if cross-domain triggered, set override and publish path to that point
        if candidate_cross:
            self.override_goal_idx = candidate_cross
            temp_planner = DStarLite(start_idx, candidate_cross, self.trav_map, self.env_map, self.resolution)
            temp_planner.compute_shortest_path()
            temp_path = temp_planner.extract_path()
            self.publish_path(temp_path)
            return

        # normal publish to goal_idx
        self.publish_path(path_indices)

        # Pure Pursuit 控制
        lookahead_dist = rospy.get_param('~lookahead_dist', 0.8)
        max_linear = rospy.get_param('~max_linear_speed', 0.1)
        k_omega     = rospy.get_param('~omega_gain', 1.0)
        # convert grid to world positions
        world_path = [(self.origin.x + (j+0.5)*self.resolution,
                       self.origin.y + (i+0.5)*self.resolution)
                      for (i,j) in path_indices]
        cx = self.current_ps.pose.position.x
        cy = self.current_ps.pose.position.y
        q  = self.current_ps.pose.orientation
        _, _, yaw = euler_from_quaternion([q.x, q.y, q.z, q.w])
        # find lookahead point
        target = None
        for px, py in world_path:
            if math.hypot(px-cx, py-cy) >= lookahead_dist:
                target = (px, py)
                break
        if not target and world_path:
            target = world_path[-1]
        if target:
            tx, ty = target
            angle_to = math.atan2(ty-cy, tx-cx)
            err = math.atan2(math.sin(angle_to-yaw), math.cos(angle_to-yaw))
            dist_err = math.hypot(tx-cx, ty-cy)
            if abs(err) > math.pi/2:
                # reverse
                err = err - math.copysign(math.pi, err)
                linear = -min(max_linear, dist_err)
            else:
                linear = min(max_linear, dist_err)
            omega = k_omega * err
        else:
            linear = 0.0; omega = 0.0
        twist = Twist()
        twist.linear.x  = linear
        twist.angular.z = omega
        self.cmd_pub.publish(twist)

if __name__ == '__main__':
    try:
        DStarPlannerNode()
    except rospy.ROSInterruptException:
        pass

