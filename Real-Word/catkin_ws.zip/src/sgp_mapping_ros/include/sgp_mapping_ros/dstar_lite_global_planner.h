#ifndef SGP_MAPPING_ROS_DSTARLITEGLOBALPLANNER_H
#define SGP_MAPPING_ROS_DSTARLITEGLOBALPLANNER_H

#include <ros/ros.h>
#include <nav_core/base_global_planner.h>
#include <geometry_msgs/PoseStamped.h>
#include <nav_msgs/Path.h>
#include <costmap_2d/costmap_2d_ros.h>

namespace sgp_mapping_ros
{

/**
 * DStarLiteGlobalPlanner
 *
 * 这是一个“全局规划器插件”的骨架类，继承自 nav_core::BaseGlobalPlanner。
 * 当你在 move_base 启动参数里把 base_global_planner 指向 "sgp_mapping_ros/DStarLiteGlobalPlanner" 时，
 * move_base 会自动用这个类来计算全局路径（而不是默认的 NavFn/A*）。
 *
 * 重要接口：
 *   - initialize(const std::string& name, costmap_2d::Costmap2DROS* costmap_ros)
 *       在 move_base 启动时被调用一次，你可以在这里拿到 costmap2DROS 指针、读取 ROS 参数等。
 *   - makePlan(const geometry_msgs::PoseStamped& start,
 *              const geometry_msgs::PoseStamped& goal,
 *              std::vector<geometry_msgs::PoseStamped>& plan)
 *       每当 move_base 收到新的导航目标（goal）时，会调用这个函数，传入“起点、目标”，
 *       你要在这里运行 D* Lite 算法，产生一条“规划路径”，并把结果填到 plan 里。
 */
class DStarLiteGlobalPlanner : public nav_core::BaseGlobalPlanner
{
public:
  DStarLiteGlobalPlanner();
  DStarLiteGlobalPlanner(std::string name, costmap_2d::Costmap2DROS* costmap_ros);

  /**
   * initialize：move_base 在启动时、加载插件时会调用这一串接口。
   * @param name：插件在参数服务器中对应的命名空间 /<name>/
   * @param costmap_ros：指向 move_base 的 costmap2d 封装，你可以通过它获取 costmap2D、分辨率、世界坐标系等信息。
   */
  void initialize(std::string name, costmap_2d::Costmap2DROS* costmap_ros) override;

  /**
   * makePlan：当 move_base 需要新的全局规划时会调用这个接口。
   * 你要把规划结果（一连串 PoseStamped）塞到 plan 里，move_base 随后会把它发给 local_planner 执行。
   * 如果完全规划失败，返回 false。
   */
  bool makePlan(const geometry_msgs::PoseStamped& start,
                const geometry_msgs::PoseStamped& goal,
                std::vector<geometry_msgs::PoseStamped>& plan) override;

private:
  bool initialized_;

  costmap_2d::Costmap2DROS* costmap_ros_;   // move_base 给的 costmap2dROS 指针
  costmap_2d::Costmap2D* costmap_;          // 真正执行规划时会用到的 costmap2D

  // D* Lite 核心成员：
  //  你需要在这里添加“D* Lite 需要的数据结构”，
  //  例如：起点/终点的格子索引，traversability/costmap 缓存等。
  //  也许你会把 Python 的 world_to_grid、cost 更新逻辑移植到这里来。
  //
  // std::vector<std::vector<float>> traversability_map_;
  // std::vector<std::vector<unsigned char>> environment_map_;
  // … 其它你需要缓存的矩阵 …

  // 帮助函数：将 ROS 的世界坐标转换成 costmap 网格索引
  unsigned int worldToMapIndex(double wx, double wy, unsigned int& mx, unsigned int& my);

  // 核心函数：运行 D* Lite 算法，生成一条“从 start 到 goal”的格子序列，最后把它塞到 plan 里
  bool computeDStarLitePlan(const geometry_msgs::PoseStamped& start,
                            const geometry_msgs::PoseStamped& goal,
                            std::vector<geometry_msgs::PoseStamped>& plan);
};

}  // namespace sgp_mapping_ros

#endif  // SGP_MAPPING_ROS_DSTARLITEGLOBALPLANNER_H

