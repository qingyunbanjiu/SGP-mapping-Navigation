#ifndef SGP_MAPPING_ROS_SGP_COSTMAP_LAYER_H
#define SGP_MAPPING_ROS_SGP_COSTMAP_LAYER_H

#include <ros/ros.h>
#include <costmap_2d/layer.h>
#include <costmap_2d/layered_costmap.h>
#include <costmap_2d/costmap_layer.h>
#include <nav_msgs/OccupancyGrid.h>
#include <costmap_2d/costmap_2d.h>
#include <mutex>

namespace sgp_mapping_ros
{

  /**
   * @brief SGPCostmapLayer 继承自 costmap_2d::CostmapLayer，
   *        用来将 /sgp_traversability_grid 发布的 OccupancyGrid 叠加到 costmap2D 中。
   *
   * 这个 Layer 会订阅 "/sgp_traversability_grid"。当收到消息后，先把它转换
   * 成一个内部保存的 Costmap2D（m_trav_costmap_），然后在 updateCosts() 里，将
   * 该内部 Costmap2D 按照世界坐标 → master_grid 的索引 映射一次，覆盖 master_grid。
   */
  class SGPCostmapLayer : public costmap_2d::CostmapLayer
  {
  public:
    SGPCostmapLayer() : layered_costmap_(nullptr), trav_grid_received_(false) {}

    virtual void onInitialize();
    virtual void updateBounds(double robot_x, double robot_y, double robot_yaw,
                              double* min_x, double* min_y, double* max_x, double* max_y);
    virtual void updateCosts(costmap_2d::Costmap2D& master_grid,
                             int min_i, int min_j, int max_i, int max_j);
    virtual void matchSize();

  private:
    void traversabilityCallback(const nav_msgs::OccupancyGridConstPtr& msg);

    std::string trav_topic_;
    ros::Subscriber trav_sub_;

    costmap_2d::Costmap2D trav_costmap_;   ///< 存储从 OccupancyGrid 把 data 拷贝过来的 2D costmap
    std::mutex trav_mutex_;
    bool trav_grid_received_;

    costmap_2d::LayeredCostmap* layered_costmap_;
  };

}  // namespace sgp_mapping_ros

#endif  // SGP_MAPPING_ROS_SGP_COSTMAP_LAYER_H

