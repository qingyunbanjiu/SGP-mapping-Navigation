#include "sgp_mapping_ros/sgp_costmap_layer.h"
#include <pluginlib/class_list_macros.h>
#include <tf2_ros/buffer.h>
#include <tf2_ros/transform_listener.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>  // for doTransform
#include <tf2_sensor_msgs/tf2_sensor_msgs.h>
#include <geometry_msgs/TransformStamped.h>

namespace sgp_mapping_ros
{

void SGPCostmapLayer::onInitialize()
{
  ros::NodeHandle nh("~/" + name_);  // name_ 是父类 CostmapLayer 给的一个标识

  // 这里可以让用户通过 param 自定义 topic 名称，默认 "/sgp_traversability_grid"
  trav_topic_ = nh.param<std::string>("traversability_topic", "/sgp_traversability_grid");

  // 订阅 /sgp_traversability_grid
  trav_sub_ = nh.subscribe(trav_topic_, 1,
                           &SGPCostmapLayer::traversabilityCallback, this);

  // 与 LayeredCostmap 绑定
  layered_costmap_ = layered_costmap_;

  trav_grid_received_ = false;
}

void SGPCostmapLayer::matchSize()
{
  // 被父类调用时，需要跟 master costmap 大小保持一致
  Costmap2D* master = layered_costmap_->getCostmap();
  trav_costmap_.resizeMap(master->getSizeInCellsX(),
                          master->getSizeInCellsY(),
                          master->getResolution(),
                          master->getOriginX(),
                          master->getOriginY());
}

void SGPCostmapLayer::traversabilityCallback(const nav_msgs::OccupancyGridConstPtr& msg)
{
  std::lock_guard<std::mutex> lock(trav_mutex_);

  // 如果收到的 resolution 与 trav_costmap_ 不一致，需要 resize 的话，这里直接重新 resize
  if (std::fabs(trav_costmap_.getResolution() - msg->info.resolution) > 1e-6 ||
      msg->info.width != trav_costmap_.getSizeInCellsX() ||
      msg->info.height != trav_costmap_.getSizeInCellsY() ||
      std::fabs(trav_costmap_.getOriginX() - msg->info.origin.position.x) > 1e-6 ||
      std::fabs(trav_costmap_.getOriginY() - msg->info.origin.position.y) > 1e-6)
  {
    trav_costmap_.resizeMap(msg->info.width,
                            msg->info.height,
                            msg->info.resolution,
                            msg->info.origin.position.x,
                            msg->info.origin.position.y);
  }

  // 把 msg->data 拷贝到 trav_costmap_ 中
  unsigned int mx, my;
  for (unsigned int y = 0; y < msg->info.height; ++y)
  {
    for (unsigned int x = 0; x < msg->info.width; ++x)
    {
      int idx = x + y * msg->info.width;
      int8_t v = msg->data[idx];  // -1~100
      if (v < 0)  // unknown
      {
        trav_costmap_.setCost(x, y, costmap_2d::NO_INFORMATION);
      }
      else
      {
        // 假设 v ∈ [0,100]，直接对应 costmap cost
        trav_costmap_.setCost(x, y, static_cast<unsigned char>(v));
      }
    }
  }
  trav_grid_received_ = true;
}

void SGPCostmapLayer::updateBounds(double robot_x, double robot_y, double robot_yaw,
                                   double* min_x, double* min_y,
                                   double* max_x, double* max_y)
{
  // 这一层没有自己维护 region bounding box，因此我们不做任何处理。
  // 由子类 updateCosts() 决定哪些 cell 会被覆盖。这里保持不动即可。
}

void SGPCostmapLayer::updateCosts(costmap_2d::Costmap2D& master_grid,
                                   int min_i, int min_j, int max_i, int max_j)
{
  if (!trav_grid_received_)
    return;

  std::lock_guard<std::mutex> lock(trav_mutex_);

  // master_grid: 分辨率假设为 0.05m；trav_costmap_ 分辨率假设为 0.4m
  // 我们需要把 trav_costmap_（每格 0.4m）投影到 master_grid。具体方法：
  //   对于 trav_costmap_ 里每个 (ix, iy)，先计算它对应的世界坐标 (wx, wy)：
  //     wx = origin_x_of_trav + ix * res_trav
  //     wy = origin_y_of_trav + iy * res_trav
  //   再让 master_grid.worldToMap(wx, wy, mx, my)，变回 master costmap 的索引
  //
  //   然后如果 new_cost = trav_costmap_.getCost(ix, iy) 不是 NO_INFORMATION，
  //   就把 master_grid.setCost(mx, my, new_cost)。这会覆盖原来的 static/obstacle cost。

  double res_trav = trav_costmap_.getResolution();
  double ox_trav  = trav_costmap_.getOriginX();
  double oy_trav  = trav_costmap_.getOriginY();

  unsigned int trav_w = trav_costmap_.getSizeInCellsX();
  unsigned int trav_h = trav_costmap_.getSizeInCellsY();

  for (unsigned int iy = 0; iy < trav_h; ++iy)
  {
    for (unsigned int ix = 0; ix < trav_w; ++ix)
    {
      unsigned char cost = trav_costmap_.getCost(ix, iy);
      if (cost == costmap_2d::NO_INFORMATION)
        continue;

      // 计算 (ix,iy) 在 trav_costmap_ 中对应的世界坐标
      double wx = ox_trav + (static_cast<double>(ix) + 0.5) * res_trav;
      double wy = oy_trav + (static_cast<double>(iy) + 0.5) * res_trav;

      unsigned int mx, my;
      if (!master_grid.worldToMap(wx, wy, mx, my))
        continue;  // 如果超出 master_grid 范围，跳过

      // 最后，把 trav layer 的 cost 写到 master costmap
      master_grid.setCost(mx, my, cost);
    }
  }
}

}  // namespace sgp_mapping_ros

// 插件注册：告诉 pluginlib 我们实现了哪个类
PLUGINLIB_EXPORT_CLASS(sgp_mapping_ros::SGPCostmapLayer, costmap_2d::Layer)

