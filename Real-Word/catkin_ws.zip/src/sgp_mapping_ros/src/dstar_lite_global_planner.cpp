#include "sgp_mapping_ros/dstar_lite_global_planner.h"
#include <pluginlib/class_list_macros.h>
#include <tf2_ros/transform_listener.h>
#include <geometry_msgs/TransformStamped.h>

using namespace sgp_mapping_ros;

namespace sgp_mapping_ros
{

DStarLiteGlobalPlanner::DStarLiteGlobalPlanner()
  : initialized_(false), costmap_ros_(nullptr), costmap_(nullptr)
{
}

DStarLiteGlobalPlanner::DStarLiteGlobalPlanner(std::string name, costmap_2d::Costmap2DROS* costmap_ros)
  : initialized_(false), costmap_ros_(nullptr), costmap_(nullptr)
{
  initialize(name, costmap_ros);
}

void DStarLiteGlobalPlanner::initialize(std::string name, costmap_2d::Costmap2DROS* costmap_ros)
{
  if (initialized_)
  {
    ROS_WARN("DStarLiteGlobalPlanner: Already initialized, skipping.");
    return;
  }

  costmap_ros_ = costmap_ros;
  costmap_ = costmap_ros_->getCostmap();

  ros::NodeHandle private_nh("~/" + name);
  ROS_INFO("DStarLiteGlobalPlanner: Initializing with name=%s", name.c_str());

  // —— 这里你可以加载参数，比如：
  // private_nh.param("some_param", some_value, default_value);

  // 初始化 D* Lite 算法需要的成员：traversability_map、environment_map、normal_map 等
  // 你可以先把整个 costmap_( ) 拷贝一份到自己的二维数组里，
  // 然后 D* Lite 在运行时就在这张地图上做 A*/D*Lite 搜索。
  // 例如：
  // unsigned int size_x = costmap_->getSizeInCellsX();
  // unsigned int size_y = costmap_->getSizeInCellsY();
  // traversability_map_.assign(size_x, std::vector<float>(size_y, 0.0f));
  // environment_map_.assign(size_x, std::vector<unsigned char>(size_y, 0));

  initialized_ = true;
}

bool DStarLiteGlobalPlanner::makePlan(const geometry_msgs::PoseStamped& start,
                                      const geometry_msgs::PoseStamped& goal,
                                      std::vector<geometry_msgs::PoseStamped>& plan)
{
  if (!initialized_)
  {
    ROS_ERROR("DStarLiteGlobalPlanner: Planner has not been initialized, please call initialize() before makePlan().");
    return false;
  }

  plan.clear();

  // —— 1) 把 start/goal 从 world (map) → costmap 网格索引 —— //
  unsigned int start_mx, start_my, goal_mx, goal_my;
  if (!worldToMapIndex(start.pose.position.x, start.pose.position.y, start_mx, start_my))
  {
    ROS_ERROR("DStarLiteGlobalPlanner: Start position (%.2f, %.2f) is out of costmap bounds", 
              start.pose.position.x, start.pose.position.y);
    return false;
  }
  if (!worldToMapIndex(goal.pose.position.x, goal.pose.position.y, goal_mx, goal_my))
  {
    ROS_ERROR("DStarLiteGlobalPlanner: Goal position (%.2f, %.2f) is out of costmap bounds", 
              goal.pose.position.x, goal.pose.position.y);
    return false;
  }

  ROS_INFO("DStarLiteGlobalPlanner: Planning from [%u, %u] → [%u, %u]", start_mx, start_my, goal_mx, goal_my);

  // —— 2) 调用 computeDStarLitePlan()（后续你要把 D* Lite 算法写在这个函数里） —— //
  bool success = computeDStarLitePlan(start, goal, plan);
  if (!success)
  {
    ROS_WARN("DStarLiteGlobalPlanner: computeDStarLitePlan() returned failure.");
    return false;
  }

  ROS_INFO("DStarLiteGlobalPlanner: makePlan() succeeded, path length = %zu", plan.size());
  return true;
}

unsigned int DStarLiteGlobalPlanner::worldToMapIndex(double wx, double wy, unsigned int& mx, unsigned int& my)
{
  if (costmap_->worldToMap(wx, wy, mx, my))
  {
    return true;
  }
  return false;
}

bool DStarLiteGlobalPlanner::computeDStarLitePlan(const geometry_msgs::PoseStamped& start,
                                                  const geometry_msgs::PoseStamped& goal,
                                                  std::vector<geometry_msgs::PoseStamped>& plan)
{
  // 这里仅演示一个非常简单的“直线路径”伪实现，用来保证 framework 能跑通。
  // 后续你再把真正的 D* Lite 逻辑移植到这里、用 traversability_map_、environment_map_ 做搜索并返回 plan。

  // 伪：如果 start/goal 非同一点，就生成 2 个点的“直线路径”：
  plan.push_back(start);
  plan.push_back(goal);
  return true;
}

}  // namespace sgp_mapping_ros

// 最后一行注册 pluginlib，让 move_base 能加载到 DStarLiteGlobalPlanner
PLUGINLIB_EXPORT_CLASS(sgp_mapping_ros::DStarLiteGlobalPlanner, nav_core::BaseGlobalPlanner)

