#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
sgp_mapping_node.py

功能：
    1. 订阅 /point_cloud_raw (sensor_msgs/PointCloud2)
    2. 使用 TF2 将 sensor frame → odom_combined，提取 XYZ 存为 NumPy 数组
    3. 在 timer_callback 中执行 SGP 拟合 (run_sgp_mapping)，得到 0.4m 网格 (xx_grid, yy_grid) 下的
       mean, slope, var (预测方差)
    4. 将 mean 插值到 0.4m、根据 local_range 与 var 淘汰无效 → 发布本地地图 MarkerArray
    5. 用 run_sgp_mapping 得到的 mean 计算 flatness、step_height、semantic、traversability，
       并分别发布对应的 MarkerArray
    6. 维护一个全局字典，将每个 local_range 范围内的有效 mean 累加到全局 → 发布全局地图 MarkerArray
"""


import rospy
import tf2_ros
import tf2_sensor_msgs.tf2_sensor_msgs as tf2_sensor
import numpy as np
from scipy.ndimage import uniform_filter, maximum_filter, minimum_filter
from scipy import ndimage
import torch
import gpytorch
from time import time
from sklearn.metrics import mean_squared_error, r2_score
from sensor_msgs.msg import PointCloud2
from visualization_msgs.msg import Marker, MarkerArray
import sensor_msgs.point_cloud2 as pc2
from scipy.interpolate import griddata
from nav_msgs.msg import OccupancyGrid, MapMetaData
from std_msgs.msg import Header
import open3d as o3d
from gpytorch.variational import VariationalStrategy, CholeskyVariationalDistribution
from gpytorch.models import ApproximateGP
from gpytorch.mlls import VariationalELBO
# ==================== SGP 模型定义 ====================
# ==================== SGP 模型定义 ====================
class SGPModel(gpytorch.models.ExactGP):
    def __init__(self, train_x, train_y, likelihood, inducing_points):
        super(SGPModel, self).__init__(train_x, train_y, likelihood)
        self.mean_module = gpytorch.means.ConstantMean()
        base_kernel = gpytorch.kernels.ScaleKernel(
            gpytorch.kernels.RBFKernel(lengthscale=torch.tensor([0.7, 0.7]))
        )
        self.covar_module = gpytorch.kernels.InducingPointKernel(
            base_kernel,
            inducing_points=inducing_points,
            likelihood=likelihood
        )

    def forward(self, x):
        mean_x = self.mean_module(x)
        covar_x = self.covar_module(x)
        return gpytorch.distributions.MultivariateNormal(mean_x, covar_x)

# ==================== SGP 拟合函数 ====================
def run_sgp_mapping(x0, y0, xyz_points, local_range=3.0, device=None):
    """
    对局部点云进行 SGP 拟合，返回：
      xx_grid, yy_grid: 0.4m 分辨率网格 (Ny, Nx)
      mean_grid: (Ny, Nx) 插值后高程
      slope_grid: (Ny, Nx) 插值后坡度模长
      var_grid: (Ny, Nx) 插值后预测方差
      grad_mean: (40*40, 2) 粗网格上 mean 对输入的梯度
    如果近距离点云过少 (<50)，返回 Nones
    """

    # 1. 裁剪 半径 local_range 内的点 (在局部世界坐标下)
    distance_sq = (xyz_points[:, 0] - x0) ** 2 + (xyz_points[:, 1] - y0) ** 2
    mask = distance_sq <= local_range ** 2
    local_pts = xyz_points[mask]
    if local_pts.shape[0] < 50:
        return (None,)*6

    # 2. 准备训练数据
    X_train_np = local_pts[:, :2]  # (n,2)
    y_train_np = local_pts[:, 2]   # (n,)
    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    X_train = torch.tensor(X_train_np, dtype=torch.float32, device=device)
    y_train = torch.tensor(y_train_np, dtype=torch.float32, device=device)

    # 3. 构造诱导点
    inducing_num = min(50, X_train.shape[0])
    idx_np = np.linspace(0, X_train.shape[0] - 1, inducing_num, dtype=int)
    idx_tensor = torch.tensor(idx_np, dtype=torch.long, device=device)
    inducing_pts = X_train[idx_tensor, :].clone()

    # 4. 创建并训练 SGP 模型
    likelihood = gpytorch.likelihoods.GaussianLikelihood().to(device)
    model = SGPModel(X_train, y_train, likelihood, inducing_pts).to(device)
    model.train()
    likelihood.train()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.01)
    mll = gpytorch.mlls.ExactMarginalLogLikelihood(likelihood, model)

    # 只做一次迭代以保证速度
    optimizer.zero_grad()
    output = model(X_train)
    loss = -mll(output, y_train)
    loss.backward()
    optimizer.step()

    # 5. 构造 40×40 粗网格，范围 [x0±lr, y0±lr]
    grid_size = 20
    x_lin = np.linspace(x0 - local_range, x0 + local_range, grid_size)
    y_lin = np.linspace(y0 - local_range, y0 + local_range, grid_size)
    xx, yy = np.meshgrid(x_lin, y_lin)            # (40,40)
    X_pred_np = np.column_stack([xx.ravel(), yy.ravel()])  # (1600,2)
    X_pred = torch.tensor(X_pred_np, dtype=torch.float32,
                          requires_grad=True, device=device)

    model.eval()
    likelihood.eval()
    with torch.enable_grad():
        preds = likelihood(model(X_pred))

    # 把预测结果转回 numpy，避免 numpy() 报错
    mean_list = preds.mean.detach().cpu().tolist()
    var_list  = preds.variance.detach().cpu().tolist()

    grad_outputs = torch.ones_like(preds.mean)
    grad_mean_tensor = torch.autograd.grad(
        preds.mean, X_pred, grad_outputs=grad_outputs, retain_graph=True
    )[0]
    slope_list = torch.norm(grad_mean_tensor, dim=1).detach().cpu().tolist()

    mean = np.array(mean_list, dtype=np.float32).reshape(xx.shape)   # (40,40)
    var  = np.array(var_list, dtype=np.float32).reshape(xx.shape)    # (40,40)
    slope= np.array(slope_list, dtype=np.float32).reshape(xx.shape)  # (40,40)

    # 6. 插值到 0.4m 分辨率
    resolution = 0.5
    grid_x = np.arange(xx.min(), xx.max() + 1e-6, resolution)
    grid_y = np.arange(yy.min(), yy.max() + 1e-6, resolution)
    xx_grid, yy_grid = np.meshgrid(grid_x, grid_y)  # (Ny, Nx)

    mean_grid = griddata(
        (xx.flatten(), yy.flatten()),
        mean.flatten(),
        (xx_grid, yy_grid),
        method='nearest'
    )
    slope_grid = griddata(
        (xx.flatten(), yy.flatten()),
        slope.flatten(),
        (xx_grid, yy_grid),
        method='nearest'
    )
    var_grid = griddata(
        (xx.flatten(), yy.flatten()),
        var.flatten(),
        (xx_grid, yy_grid),
        method='nearest'
    )

    # 7. 计算训练集 RMSE 与 R^2（可打印或返回参考）
    with torch.no_grad():
        train_preds_tensor = likelihood(model(X_train)).mean.detach().cpu()
    train_preds_list = train_preds_tensor.tolist()
    train_preds = np.array(train_preds_list, dtype=np.float32)
    train_y_np = y_train_np
    mse = mean_squared_error(train_y_np, train_preds)
    rmse = np.sqrt(mse)
    r2 = r2_score(train_y_np, train_preds)
    print(f"训练集 RMSE: {rmse:.4f}")
    print(f"训练集 R²: {r2:.4f}")
    return xx_grid, yy_grid, mean_grid, slope_grid, var_grid, grad_mean_tensor, rmse, r2
    


def voxel_downsample(xyz: np.ndarray, voxel_size: float = 0.2) -> np.ndarray:
    pc = o3d.geometry.PointCloud()
    pc.points = o3d.utility.Vector3dVector(xyz)
    ds = pc.voxel_down_sample(voxel_size=voxel_size)
    return np.asarray(ds.points, dtype=np.float32)


# ==================== 计算平坦度（兼顾 NaN 不受污染版） ====================
def compute_flatness(elevation_grid, resolution=0.5, physical_window=1.2):
    """
    计算平坦度（Flatness）：基于局部窗口内高程方差，忽略 NaN。
    输出归一化到 [0,1]，无效区保持 NaN。
    """
    # 1) 由 physical_window/分辨率 得到窗口尺寸（必须奇数）
    window_size = int(np.round(physical_window / resolution))
    if window_size % 2 == 0:
        window_size += 1
    pad = window_size // 2

    H, W = elevation_grid.shape
    flatness_map = np.full((H, W), np.nan, dtype=np.float32)

    # 2) 对每个格子单独计算其窗口内的方差（过滤 NaN 再统计）
    for i in range(H):
        for j in range(W):
            if np.isnan(elevation_grid[i, j]):
                continue

            i0 = max(0, i - pad)
            i1 = min(H, i + pad + 1)
            j0 = max(0, j - pad)
            j1 = min(W, j + pad + 1)

            patch = elevation_grid[i0:i1, j0:j1]
            valid_vals = patch[~np.isnan(patch)]
            if valid_vals.size == 0:
                continue

            local_var = np.var(valid_vals)
            flatness_map[i, j] = local_var

    # 3) 归一化
    valid_mask = ~np.isnan(flatness_map)
    if np.any(valid_mask):
        max_var = np.nanmax(flatness_map)
        if max_var > 0:
            flatness_map[valid_mask] /= max_var
        else:
            flatness_map[valid_mask] = 0.0

    return flatness_map

# ==================== 计算台阶高度 ====================
def compute_step_height(elevation_grid, window_size=3):
    """
    基于高程图计算 Step Height。
    对每个格子做最大池化和最小池化，差值即为局部最高-最低。
    无效区 (NaN) 保持 NaN。
    """
    if window_size % 2 == 0:
        raise ValueError("window_size 必须是奇数")

    H, W = elevation_grid.shape
    # 用 -inf/inf 填充 nan，保证最大/最小过滤时被忽略
    tmp_max = maximum_filter(
        np.nan_to_num(elevation_grid, nan=-np.inf),
        size=window_size, mode='nearest'
    )
    tmp_min = minimum_filter(
        np.nan_to_num(elevation_grid, nan=np.inf),
        size=window_size, mode='nearest'
    )
    step_height = tmp_max - tmp_min
    # 把原来 elevation_grid 为 NaN 的地方也置为 NaN
    step_height[np.isnan(elevation_grid)] = np.nan

    return step_height

# ==================== 生成语义地图 ====================
def generate_semantic_map(mean, slope, var, step_map=None, flatness_map=None,
                          resolution=0.5, slope_thresh=0.05, elev_thresh=0.3,
                          crit_slope=0.50, crit_step=0.35, crit_flat=0.50):
    """
    基于多特征（高程、坡度、方差、台阶、高度方差）生成语义标签：  
       0=障碍（红）、1=水域（蓝）、2=可通（绿）、255=无效（灰）
    """
    h, w = mean.shape
    semantic_map = np.full((h, w), 255, dtype=np.uint8)  # 先全置为 255 (无效)

    for i in range(h):
        for j in range(w):
            if var[i, j] > 1:
                # 方差过高 (uncertainty 高) 的格子不可靠，保留 255 无效
                continue

            is_flat = slope[i, j] < slope_thresh
            is_low  = mean[i, j] < elev_thresh
            is_var_good = var[i, j] < 1.1

            # 1) 水域判定：平坦 + 低高程 + 低方差
            if is_flat and is_var_good:
                semantic_map[i, j] = 1
                continue

            # 2) 多特征障碍：任意一项超阈值
            is_obstacle = False
            if np.arctan(slope[i, j]) > crit_slope:
                is_obstacle = True
            if flatness_map is not None and not np.isnan(flatness_map[i, j]) and flatness_map[i, j] > crit_flat:
                is_obstacle = True

            if is_obstacle:
                semantic_map[i, j] = 0  # 障碍
            elif is_var_good:
                semantic_map[i, j] = 2  # 可通
            else:
                semantic_map[i, j] = 255

    # 3) 去除过小水域斑块 (<10 个格子)，否则视为可通
    water_mask = (semantic_map == 1)
    labeled, num_features = ndimage.label(water_mask)
    for lab in range(1, num_features + 1):
        region = (labeled == lab)
        if np.sum(region) < 10:
            semantic_map[region] = 2

    return semantic_map

# ==================== 计算可通行性地图 ====================
def compute_traversability_map(step_map, flatness_map, slope_map, var_map, semantic_map,
                               w_step=0.3, w_flat=0.5, w_slope=0.2,
                               crit_step=0.35, crit_flat=0.50, crit_slope=0.40,
                               var_thresh=1.9):
    """
    通过加权台阶、平坦度、坡度生成通行性代价 (0~1)，越高越难走；水域强制设为 0；障碍强制 1；方差过大设 1。
    """
    h, w = step_map.shape
    trav_map = np.zeros_like(step_map, dtype=np.float32)

    for i in range(h):
        for j in range(w):
            if var_map[i, j] > var_thresh:
                # 方差太大 → 无法信任，视作障碍，trav=1
                trav_map[i, j] = 1.0
                continue

            if semantic_map[i, j] == 1:  # 水域
                trav_map[i, j] = 0.0
                continue
            if semantic_map[i, j] == 0:  # 障碍
                trav_map[i, j] = 1.0
                continue

            # 基础加权
            trav = (w_step * (step_map[i, j] / crit_step)
                   + w_slope * (flatness_map[i, j] / crit_flat)
                   + w_flat * (slope_map[i, j] / crit_slope))
            trav = min(trav, 1.0)
            trav_map[i, j] = trav

    return trav_map

# ==================== ROS Node ====================
class SGPMappingNode:
    def __init__(self):
        rospy.init_node("sgp_mapping_node", anonymous=True)
        self.rmse_list = []
        self.r2_list   = []
        # 参数
        self.pointcloud_topic  = rospy.get_param("~pointcloud_topic",   "/point_cloud_raw")
        self.frame_id_odom     = rospy.get_param("~frame_id_odom",      "odom_combined")
        self.frame_id_base     = rospy.get_param("~frame_id_base",      "base_link")
        self.map_publish_rate  = rospy.get_param("~map_publish_rate",   0.2)
        self.local_range       = rospy.get_param("~local_range",        2.5)
        self.resolution        = rospy.get_param("~resolution",         0.5)

        # 初始化 init_x, init_y（开机时机器人在 odom 坐标下的位置）
        self.init_x = None
        self.init_y = None

        # TF 监听器
        self.tf_buffer   = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer)

        # ① 点云订阅：收到后直接用 tf2 把 sensor frame → odom_combined，然后提取 XYZ
        self.latest_xyz_odom = None
        self.pc_sub = rospy.Subscriber(
            self.pointcloud_topic, PointCloud2,
            self.pointcloud_callback, queue_size=1
        )

        # ② 发布：本地地图 & 全局地图 & 几个特征地图
        self.local_pub    = rospy.Publisher("/sgp_local_map_markers",   MarkerArray, queue_size=1)
        self.global_pub   = rospy.Publisher("/sgp_global_map_markers",  MarkerArray, queue_size=1)
        self.flatness_pub = rospy.Publisher("/sgp_flatness_markers",    MarkerArray, queue_size=1)
        self.step_pub     = rospy.Publisher("/sgp_step_height_markers", MarkerArray, queue_size=1)
        self.semantic_pub = rospy.Publisher("/sgp_semantic_markers",    MarkerArray, queue_size=1)
        self.trav_pub     = rospy.Publisher("/sgp_traversability_markers", MarkerArray, queue_size=1)
        self.slope_pub = rospy.Publisher("/sgp_slope_markers", MarkerArray, queue_size=1)
        self.uncertainty_pub = rospy.Publisher("/sgp_uncertainty_markers", MarkerArray, queue_size=1)
        #self.trav_grid_pub = rospy.Publisher("/sgp_traversability_grid",
                                     #OccupancyGrid, queue_size=1)
        # 全局通行性字典（任意扩展大小）

        self.global_env_map  = {}   # key=(i_idx,j_idx) -> int obstacle flag (0/1)
        
        self.global_trav_map = {}   # key=(i_idx,j_idx) -> float traversability 0~1
        # 发布全局静态 OccupancyGrid（不随局部 window 漂移）
        self.trav_grid_pub = rospy.Publisher(
            '/sgp_global_traversability', OccupancyGrid, queue_size=1
        )


        # ③ 全局地图用字典累加：key=(i_idx, j_idx)，value=mean_height
        self.global_mean_dict = {}

        # ④ 定时器：周期性调用
        self.timer = rospy.Timer(
            rospy.Duration(1.0 / self.map_publish_rate),
            self.timer_callback
        )

        rospy.loginfo("[SGP Mapping] 节点启动，订阅点云: %s (TF→%s), 周期: %.2f Hz"
                      % (self.pointcloud_topic, self.frame_id_odom, self.map_publish_rate))

    # ----------------------------------------
    def pointcloud_callback(self, msg_pc2):
        """
        PointCloud2 回调：用 tf2 把 quaternions 点云从 sensor frame → odom_combined，再提取 x,y,z。
        存储到 self.latest_xyz_odom (N×3) NumPy
        """
        try:
            cloud_odom = tf2_sensor.do_transform_cloud(
                msg_pc2,
                self.tf_buffer.lookup_transform(
                    self.frame_id_odom,
                    msg_pc2.header.frame_id,
                    rospy.Time(0), rospy.Duration(0.5)
                )
            )
        except (tf2_ros.ExtrapolationException, tf2_ros.LookupException) as ex:
            rospy.logwarn_once("[SGP Mapping] 点云 TF 转换失败：%s" % str(ex))
            return

        points_list = []
        for pt in pc2.read_points(cloud_odom, skip_nans=True, field_names=("x", "y", "z")):
            points_list.append([pt[0], pt[1], pt[2]])
        if not points_list:
            return
        xyz = np.array(points_list, dtype=np.float32)
        leaf = rospy.get_param("~voxel_leaf_size", 0.20)
        xyz = voxel_downsample(xyz, voxel_size=leaf)
        self.latest_xyz_odom = xyz
        #self.latest_xyz_odom = np.array(points_list, dtype=np.float32)

    # ----------------------------------------
    def get_robot_pose(self):
        """
        获得机器人 base_link 在 odom_combined 下的平面坐标 (x0, y0)
        """
        try:
            trans = self.tf_buffer.lookup_transform(
                self.frame_id_odom,
                self.frame_id_base,
                rospy.Time(0), rospy.Duration(0.5)
            )
            x0 = trans.transform.translation.x
            y0 = trans.transform.translation.y
            return x0, y0
        except (tf2_ros.LookupException, tf2_ros.ExtrapolationException) as ex:
            rospy.logwarn_once("[SGP Mapping] 无法获取 TF：%s" % str(ex))
            return None, None

    # ----------------------------------------
    def world_to_grid_idx(self, x_local, y_local):
        """
        局部世界坐标 (x_local, y_local) → 全局栅格索引 (i_idx, j_idx)
        i_idx = floor(x_local / resolution)，j_idx = floor(y_local / resolution)
        """
        i_idx = int(np.floor(x_local / self.resolution))
        j_idx = int(np.floor(y_local / self.resolution))
        return i_idx, j_idx

    # ----------------------------------------
    def timer_callback(self, event):
        """
        定时回调：
          1) 首次锁定 init_x, init_y
          2) 将最新点云 (odom) 转到 局部世界 (减去 init)
          3) run_sgp_mapping 得到本地 0.4m 网格 mean/slope/var
          4) 发布本地地图、flatness、step、semantic、trav 的 MarkerArray
          5) 更新全局字典 & 发布全局地图
        """
        # 如果没有获得任何点云，则跳过
        if self.latest_xyz_odom is None:
            return

        # 1) 获取机器人当前 odom 下位置
        x0_odom, y0_odom = self.get_robot_pose()
        if x0_odom is None:
            return

        # 首次启动时锁定 init 原点
        if self.init_x is None:
            self.init_x = x0_odom
            self.init_y = y0_odom
            rospy.loginfo("[SGP Mapping] 初始化原点 init=(%.3f, %.3f)"
                          % (self.init_x, self.init_y))

        # 2) 计算机器人在“局部世界”下的坐标 (x0_local, y0_local)
        x0_local = x0_odom - self.init_x
        y0_local = y0_odom - self.init_y

        # 将最新收到的全局点云 (odom) 转到局部世界
        xyz_points_local = self.latest_xyz_odom.copy()
        xyz_points_local[:, 0] -= self.init_x
        xyz_points_local[:, 1] -= self.init_y

        # 3) 执行 SGP 拟合，得到 0.4m 网格下的 mean, slope, var
        t0 = time()
        results = run_sgp_mapping(
            x0_local, y0_local, xyz_points_local,
            local_range=self.local_range
        )
        if results[0] is None:
            rospy.loginfo_throttle(5.0, "[SGP Mapping] 最近点云过少 (<50)，跳过 SGP 拟合")
            return

        t1 = time()
        rospy.loginfo("[SGP] 拟合耗时: %.3f s"%(t1-t0))
        xx_grid, yy_grid, mean_grid, slope_grid, var_grid, grad_mean, rmse, r2 = results
        
        self.rmse_list.append(rmse)
        self.r2_list.append(r2)
        
        # 4) 先把超出 local_range 或 var 过大部分置为 NaN
        dist_sq = (xx_grid - x0_local)**2 + (yy_grid - y0_local)**2
        mask_outside = dist_sq > (self.local_range**2)
        mean_grid[mask_outside]  = np.nan
        slope_grid[mask_outside] = np.nan
        var_grid[mask_outside]   = np.nan

        #var_thresh = 1.5
        #mask_high_var = var_grid > var_thresh
        #mean_grid[mask_high_var]  = np.nan
        #slope_grid[mask_high_var] = np.nan
        #var_grid[mask_high_var]   = np.nan

        # ----- 4.1 计算平坦度 & 台阶高度 & 语义 & 通行性 -----
        flatness_map = compute_flatness(
            elevation_grid = mean_grid,
            resolution     = self.resolution,
            physical_window= 1.2
        )
        step_map = compute_step_height(mean_grid, window_size=3)
        semantic_map = generate_semantic_map(
            mean         = mean_grid,
            slope        = slope_grid,
            var          = var_grid,
            step_map     = step_map,
            flatness_map = flatness_map,
            resolution   = self.resolution,
            slope_thresh = 0.05,
            elev_thresh  = 0.35,
            crit_slope   = 0.40,
            crit_step    = 0.35,
            crit_flat    = 0.50
        )
        trav_map = compute_traversability_map(
            step_map     = step_map,
            flatness_map = flatness_map,
            slope_map    = slope_grid,
            var_map      = var_grid,
            semantic_map = semantic_map,
            w_step       = 0.3,
            w_flat       = 0.5,
            w_slope      = 0.2,
            crit_step    = 0.35,
            crit_flat    = 0.55,
            crit_slope   = 0.45,
            var_thresh   = 1.6
        )
        

        # ---------- 4.2 发布“本地 높도（mean）” MarkerArray ----------
        t0 = time()
        local_array = MarkerArray()
        marker_id = 0
        max_h = float(np.nanmax(mean_grid)) if not np.all(np.isnan(mean_grid)) else 0.0
        min_h = float(np.nanmin(mean_grid)) if not np.all(np.isnan(mean_grid)) else 0.0
        Ny, Nx = mean_grid.shape

        for i in range(Ny):
            for j in range(Nx):
                z_val = mean_grid[i, j]
                if np.isnan(z_val):
                    continue
                m = Marker()
                m.header.frame_id = self.frame_id_odom
                m.header.stamp = rospy.Time.now()
                m.ns = "sgp_local_height"
                m.id = marker_id
                marker_id += 1

                m.type = Marker.CUBE
                m.action = Marker.ADD

                x_l = float(xx_grid[i, j])
                y_l = float(yy_grid[i, j])
                x_o = x_l + self.init_x
                y_o = y_l + self.init_y

                m.pose.position.x = x_o
                m.pose.position.y = y_o
                m.pose.position.z = z_val / 2.0
                m.pose.orientation.x = 0.0
                m.pose.orientation.y = 0.0
                m.pose.orientation.z = 0.0
                m.pose.orientation.w = 1.0

                m.scale.x = self.resolution
                m.scale.y = self.resolution
                m.scale.z = max(0.00, z_val)  # 最低高度 5cm

                if max_h - min_h > 1e-3:
                    norm_h = (z_val - min_h) / (max_h - min_h)
                else:
                    norm_h = 0.0
                # 用蓝-红渐变：高程越高 → R 越大，低程偏蓝
                m.color.r = norm_h
                m.color.g = 0.0
                m.color.b = 1.0 - norm_h
                m.color.a = 0.8

                m.lifetime = rospy.Duration(0.0)
                local_array.markers.append(m)

        self.local_pub.publish(local_array)
        
# ────── 新增代码：构造并发布 /sgp_traversability_grid ──────
# 假设此时已经有：
#    xx_grid (Ny×Nx), yy_grid (Ny×Nx)
#    traversability_map (Ny×Nx，float 0~1, NaN 表示外圈/未扫描)
#
# 我们先在 Python 里确定一个全局 Grid 的宽高。示例这里用 
# Ny = traversability_map.shape[0], Nx = traversability_map.shape[1]
        # --- 更新全局通行性字典 ---
        # trav_map: Ny×Nx、已归一化（0~1），1=障碍、0=完全可行
        Ny, Nx = trav_map.shape
        for i in range(Ny):
            for j in range(Nx):
                tv = trav_map[i, j]
                if np.isnan(tv):
                    continue
                # 将局部格子坐标 (xx_grid, yy_grid) 转到世界坐标
                x_w = xx_grid[i, j] + self.init_x
                y_w = yy_grid[i, j] + self.init_y
                # 以 init 原点做全局网格索引
                gi, gj = self.world_to_grid_idx(x_w, y_w)
                # 累积到全局字典
                self.global_trav_map[(gi, gj)] = tv

        # --- 构造并发布全局 OccupancyGrid ---
        grid = OccupancyGrid()
        grid.header.frame_id = self.frame_id_odom
        grid.header.stamp    = rospy.Time.now()
        grid.info.resolution = self.resolution
        # 计算全局网格边界
        is_, js_ = zip(*self.global_trav_map.keys())
        imin, imax = min(is_), max(is_)
        jmin, jmax = min(js_), max(js_)
        grid.info.width  = jmax - jmin + 1
        grid.info.height = imax - imin + 1
        # origin 对齐到 (imin, jmin) 的世界坐标
        grid.info.origin.position.x = imin * self.resolution + self.init_x
        grid.info.origin.position.y = jmin * self.resolution + self.init_y
        grid.info.origin.orientation.w = 1.0

        # 填 data：-1 表示 unknown，0~100 表示 cost
        grid.data = []
        for i in range(imin, imax + 1):
            for j in range(jmin, jmax + 1):
                tv = self.global_trav_map.get((i, j), np.nan)
                if np.isnan(tv):
                    grid.data.append(-1)
                else:
                    grid.data.append(int(min(100, max(0, tv * 100))))
        # 发布
        self.trav_grid_pub.publish(grid)

        
        



        # ---------- 4.6 发布“Semantic（语义）” MarkerArray ----------
        sem_array = MarkerArray()
        sid2 = 0
        Ny, Nx = semantic_map.shape
        for i in range(Ny):
            for j in range(Nx):
                sval = semantic_map[i, j]
                if sval == 255:
                    # 无效区域，不发布
                    continue
                m = Marker()
                m.header.frame_id = self.frame_id_odom
                m.header.stamp = rospy.Time.now()
                m.ns = "sgp_semantic"
                m.id = sid2
                sid2 += 1

                m.type = Marker.CUBE
                m.action = Marker.ADD

                x_l = float(xx_grid[i, j])
                y_l = float(yy_grid[i, j])
                x_o  = x_l + self.init_x
                y_o  = y_l + self.init_y
                z_val = 0.05
                m.pose.position.x = x_o
                m.pose.position.y = y_o
                m.pose.position.z = z_val / 2.0
                m.pose.orientation.x = 0.0
                m.pose.orientation.y = 0.0
                m.pose.orientation.z = 0.0
                m.pose.orientation.w = 1.0

                m.scale.x = self.resolution
                m.scale.y = self.resolution
                m.scale.z = z_val

                # 语义着色：0=障碍(红)、1=水域(蓝)、2=可通(绿)
                if sval == 0:
                    m.color.r = 1.0; m.color.g = 0.0; m.color.b = 0.0; m.color.a = 0.8
                elif sval == 1:
                    m.color.r = 0.0; m.color.g = 0.0; m.color.b = 1.0; m.color.a = 0.8
                elif sval == 2:
                    m.color.r = 0.0; m.color.g = 1.0; m.color.b = 0.0; m.color.a = 0.8

                m.lifetime = rospy.Duration(0.0)
                sem_array.markers.append(m)
        self.semantic_pub.publish(sem_array)

        # ---------- 4.7 发布“Traversability（通行性）” MarkerArray ----------
        trav_array = MarkerArray()
        tid = 0
        if not np.all(np.isnan(trav_map)):
            Ny, Nx = trav_map.shape
            # trav_map 归一化本身就是 0~1
            for i in range(Ny):
                for j in range(Nx):
                    tval = trav_map[i, j]
                    if np.isnan(tval):
                        continue
                    m = Marker()
                    m.header.frame_id = self.frame_id_odom
                    m.header.stamp = rospy.Time.now()
                    m.ns = "sgp_traversability"
                    m.id = tid
                    tid += 1

                    m.type = Marker.CUBE
                    m.action = Marker.ADD

                    x_l = float(xx_grid[i, j])
                    y_l = float(yy_grid[i, j])
                    x_o  = x_l + self.init_x
                    y_o  = y_l + self.init_y
                    z_val = 0.05
                    m.pose.position.x = x_o
                    m.pose.position.y = y_o
                    m.pose.position.z = z_val / 2.0
                    m.pose.orientation.x = 0.0
                    m.pose.orientation.y = 0.0
                    m.pose.orientation.z = 0.0
                    m.pose.orientation.w = 1.0

                    m.scale.x = self.resolution
                    m.scale.y = self.resolution
                    m.scale.z = z_val

                    # 红→黄渐变：tval 越高越红；tval 越低越黄
                    # R=1, G=(1 - tval), B=0
                    if tval <= 0.0:
                        m.color.r = 1.0
                        m.color.g = 1.0
                        m.color.b = 1.0
                    elif tval >= 1.0:
                        m.color.r = 0.0
                        m.color.g = 0.0
                        m.color.b = 0.0
                    else:
                        m.color.r = 1.0
                        m.color.g = 1.0 - tval
                        m.color.b = 0.0
                    m.color.a = 0.8

                    m.lifetime = rospy.Duration(0.0)
                    trav_array.markers.append(m)
        self.trav_pub.publish(trav_array)

        # ---------- 5) 更新 & 发布 全局地图 ----------
        for i in range(Ny):
            for j in range(Nx):
                mean_val = mean_grid[i, j]
                if np.isnan(mean_val):
                    continue
                x_l = float(xx_grid[i, j])
                y_l = float(yy_grid[i, j])
                i_idx, j_idx = self.world_to_grid_idx(x_l, y_l)
                key = (i_idx, j_idx)
                if key not in self.global_mean_dict:
                    self.global_mean_dict[key] = float(mean_val)

        global_array = MarkerArray()
        mk_id = 0
        if len(self.global_mean_dict) > 0:
            all_means = np.array(list(self.global_mean_dict.values()), dtype=np.float32)
            g_min = float(np.nanmin(all_means))
            g_max = float(np.nanmax(all_means))
        else:
            g_min, g_max = 0.0, 1.0

        for (i_idx, j_idx), m_val in self.global_mean_dict.items():
            x_l = i_idx * self.resolution
            y_l = j_idx * self.resolution
            x_o = x_l + self.init_x
            y_o = y_l + self.init_y
            z_o = m_val

            m2 = Marker()
            m2.header.frame_id = self.frame_id_odom
            m2.header.stamp = rospy.Time.now()
            m2.ns = "sgp_global_height"
            m2.id = mk_id
            mk_id += 1

            m2.type = Marker.CUBE
            m2.action = Marker.ADD
            m2.pose.position.x = x_o
            m2.pose.position.y = y_o
            m2.pose.position.z = z_o / 2.0
            m2.pose.orientation.x = 0.0
            m2.pose.orientation.y = 0.0
            m2.pose.orientation.z = 0.0
            m2.pose.orientation.w = 1.0
            m2.scale.x = self.resolution
            m2.scale.y = self.resolution
            m2.scale.z = max(0.05, z_o)

            if g_max - g_min > 1e-3:
                norm_g = (m_val - g_min) / (g_max - g_min)
            else:
                norm_g = 0.0
            m2.color.r = norm_g
            m2.color.g = 0.0
            m2.color.b = 1.0 - norm_g
            m2.color.a = 0.8

            m2.lifetime = rospy.Duration(0.0)
            global_array.markers.append(m2)

        self.global_pub.publish(global_array)

        t1 = time()
        rospy.loginfo("[SGP] fabu耗时: %.3f s"%(t1-t0))
        rospy.loginfo_throttle(
            5.0,
            "[SGP Mapping] RobotLocal=(%.2f, %.2f), 局部栅格=(%d×%d), 全局栅格总数=%d"
            % (x0_local, y0_local, Ny, Nx, len(self.global_mean_dict))
        )
    
    def on_shutdown(self):
        if self.rmse_list:
            import numpy as np
            mean_rmse = np.mean(self.rmse_list)
            std_rmse  = np.std(self.rmse_list)
            mean_r2   = np.mean(self.r2_list)
            std_r2    = np.std(self.r2_list)
            rospy.loginfo("=== SGP Overall Performance ===")
            rospy.loginfo(f"Avg RMSE = {mean_rmse:.4f} ± {std_rmse:.4f}")
            rospy.loginfo(f"Avg R²   = {mean_r2:.4f} ± {std_r2:.4f}")

if __name__ == "__main__":
    try:
        node = SGPMappingNode()
        rospy.on_shutdown(node.on_shutdown)  # 注册关闭钩子
        rospy.spin()
    except rospy.ROSInterruptException:
        pass


