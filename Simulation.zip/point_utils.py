class Point:
    def __init__(self, x, y, z=0.0):
        self.x = x
        self.y = y
        self.z = z