import numpy as np
import sys
from generate_semantic_map import generate_semantic_map, visualize_semantic_map
from dstar_lite import DStarLite
from point_utils import Point
from utils import world_to_grid, grid_to_world
import time
import pandas as pd
import torch
import matplotlib.pyplot as plt
import math, random, time, csv, os
from collections import namedtuple
import json
# 从 informed_RRT.py 导入所需函数和类
from functions import (
    SGPModel,
    run_sgp_mapping,
    update_global_maps_from_sgp,
    is_point_valid,
    visualize_path_local_traversability1,
    is_path_fully_explored,
    extract_water_edge_from_semantic_map,
    visualize_path_local_water_edge,
    detect_structural_blockage_from_grid,
    extract_candidate_cross_points_in_radius,
    retrain_sgp_and_visualize_path,
    visualize_pointcloud_surface,
    select_virtual_goal_refined,
    try_virtual_goal_path,
    select_virtual_goal_adaptive,
    select_best_cross_domain_point,
    try_virtual_goal_path,
    car_angle,
    get_euler_from_normal,
    compute_cross_domain_risk,
    calculate_temp_target,
    analyze_three_algos
)

import warnings
warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=RuntimeWarning)
rmse_list = []
r2_list   = []


def show_global_elevation_uncertainty(global_mean_map, global_var_map, cell_size=0.4, 
                                      origin_xy=(0.0, 0.0), zoom_padding=10, save_path=None):
    """
    可视化全局SGP建图结果：自动聚焦中间有数据的区域（高程 + 不确定性）
    """
    H, W = global_mean_map.shape
    ox, oy = origin_xy
    extent = [ox, ox + W * cell_size, oy, oy + H * cell_size]

    # === 自动裁剪出非空区域 ===
    valid_mask = ~np.isnan(global_mean_map)
    if np.any(valid_mask):
        ys, xs = np.where(valid_mask)
        y_min = max(ys.min() - zoom_padding, 0)
        y_max = min(ys.max() + zoom_padding, H)
        x_min = max(xs.min() - zoom_padding, 0)
        x_max = min(xs.max() + zoom_padding, W)
    else:
        y_min, y_max, x_min, x_max = 0, H, 0, W

    plt.figure(figsize=(12, 5))

    # Elevation
    plt.subplot(1, 2, 1)
    plt.imshow(global_mean_map, cmap='viridis', origin='lower', extent=extent)
    plt.xlim((x_min * cell_size, x_max * cell_size))
    plt.ylim((y_min * cell_size, y_max * cell_size))
    plt.colorbar(label='Elevation (m)')
    plt.title("SGP Predicted Elevation (Mean)")
    plt.xlabel("X (m)")
    plt.ylabel("Y (m)")

    # Uncertainty
    plt.subplot(1, 2, 2)
    plt.imshow(global_var_map, cmap='Reds', origin='lower', extent=extent)
    plt.xlim((x_min * cell_size, x_max * cell_size))
    plt.ylim((y_min * cell_size, y_max * cell_size))
    plt.colorbar(label='Uncertainty (Variance)')
    plt.title("SGP Prediction Uncertainty")
    plt.xlabel("X (m)")
    plt.ylabel("Y (m)")

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"✅ 图像已保存至：{save_path}")
    plt.show()


def navigate_segment_with_cross_event(
      start_grid, goal_grid,global_mean_map, global_slope_map, global_roughness_map,
                global_envrionment_map, global_traversability_map,
                global_frozen_map, global_normal_map,
      use_weighted: bool,
      use_cross_domain: bool,
      use_huanjing: bool
):
    """
    从 start_grid 导航到 goal_grid；若途中触发跨域阻碍，则返回真正的跨域点。
    返回 (reached_goal: bool, path_list: List[格点], cross_pt: (i,j) or None)
    """
    t_start = time.time()   # ← 开始计时
    timeout_s=80
    planner = DStarLite(start_grid, goal_grid,
                        global_traversability_map,
                        global_envrionment_map,
                        global_normal_map,
                        use_weighted=use_weighted)
    planner.compute_shortest_path()

    current = start_grid
    path_list = [current]
    block_count = 0

    while current != goal_grid:
        # 1. 世界坐标
        elapsed = time.time() - t_start
        if elapsed > timeout_s:
            print(f"[Timeout] Navigation exceeded {timeout_s:.1f}s, aborting.")
            return False, path_list, None,  {
                    "mean_map": global_mean_map,
                    "slope_map": global_slope_map,
                    "rough_map": global_roughness_map,
                    "env_map": global_envrionment_map,
                    "trav_map": global_traversability_map,
                    "normal_map": global_normal_map,
                    "frozen": global_frozen_map
                }
        x = min_x + current[0] * resolution
        y = min_y + current[1] * resolution

        # 2. 动态建图 + 更新全局地图
        result = run_sgp_mapping(x, y)
        xx, yy, mean_g, slope_g, var_g, flat_g, step_h, sem_map, trav_map, grad_m,rmse,r2,nll_mean,training_time, infer_time,mem_peak,N_local  = result
        rmse_list.append(rmse)
        r2_list.append(r2)       
        update_global_maps_from_sgp(
            xx, yy, mean_g, slope_g, var_g,
            sem_map, trav_map, grad_m,
            global_mean_map, global_slope_map, global_roughness_map,
            global_envrionment_map, global_traversability_map,
            global_frozen_map, global_normal_map
        )

        # 3. 更新 D* Lite 起点 + 邻居 + 重算
        # 3. 更新 D* Lite 起点 + 邻居 + 重算
        old_start = planner.s_start
        planner.k_m += planner.heuristic(old_start, current)   # ← 补上这一行
        planner.s_start = current
        planner.update_vertex(current)
        for nbr in planner.get_neighbors(current):
            planner.update_vertex(nbr)
        planner.compute_shortest_path()

        # 4. 选最优 successor
        # 4. 选最优 successor（原来只看 g_val + c）
        env_now    = global_envrionment_map[current[0], current[1]]
        
        successors = planner.get_neighbors(current)
        next_grid, min_cost = None, float('inf')
        
        w_h = 0.02   # 启发式权重

        # 先在 g_val 有效的节点里找最优
        best_found = False
        for s in successors:
            if use_huanjing and global_envrionment_map[s] != env_now:
                continue
            g_val = planner.g.get(s, float('inf'))
            if g_val < float('inf'):
                c = planner.cost(current, s)
                h = planner.heuristic(s, planner.s_goal)
                score = g_val + c
                #print(s, "g_val=", g_val, "score(using g)=", score)
                if score < min_cost:
                    min_cost, next_grid = score, s
                    best_found = True

        # 如果没有任何 g_val 有效的后继，再退到纯启发式选择
        if not best_found:
            
            min_cost = float('inf')
            for s in successors:
                if use_huanjing and global_envrionment_map[s] != env_now:
                    continue
                c = planner.cost(current, s)
                h = planner.heuristic(s, planner.s_goal)
                score = c + w_h * h
                #print(s, "g_val=inf, score(using heuristic)=", score)
                if score < min_cost:
                    min_cost, next_grid = score, s



        #print("next_grid=", next_grid)
        # 5. 路径失效检测
        i, j = next_grid
        if  global_envrionment_map[i, j] == 0:
            planner.update_vertex(current)
            planner.compute_shortest_path()
            continue

        # 6. 结构性阻碍检测
        if use_cross_domain:
            
            is_blocked, _, _, _, _ = detect_structural_blockage_from_grid(
                current_grid=current,
                next_grid=next_grid,
                edge_points=np.argwhere(
                    extract_water_edge_from_semantic_map(
                        global_envrionment_map,
                        global_traversability_map
                    )
                ),
                resolution=resolution,
                min_x=min_x, min_y=min_y
            )
            block_count = block_count + 1 if is_blocked else 0
            if block_count >= 2:
                # 初步选出候选跨域点
                print("大范围结构性阻碍")
                candidate_cross = select_best_cross_domain_point(
                    water_edge_mask=extract_water_edge_from_semantic_map(
                        global_envrionment_map,
                        global_traversability_map
                    ),
                    initial_goal_grid=goal_grid,
                    initial_start_grid=start_grid,
                    current_grid=current,
                    candidate_cross_grids=extract_candidate_cross_points_in_radius(
                        current_grid=current,
                        edge_points=np.argwhere(
                            extract_water_edge_from_semantic_map(
                                global_envrionment_map,
                                global_traversability_map
                            )
                        ),
                        global_envrionment_map=global_envrionment_map,
                        resolution=resolution, radius=4.0
                    ),
                    global_traversability_map=global_traversability_map,
                    global_envrionment_map=global_envrionment_map,
                    global_normal_map=global_normal_map,
                    global_mean_map=global_mean_map,
                    weight_dist=1.0, weight_rough=2.0,
                    resolution=resolution
                )
                print("candidate_cross")
                print(candidate_cross)
                # 在候选跨域点附近再选最优跨域点
                i0, j0 = candidate_cross
                current_env = global_envrionment_map[i0, j0]
                rows, cols = global_envrionment_map.shape
                best_cross, best_cost = None, float('inf')
                for di in (-1, 0, 1):
                    for dj in (-1, 0, 1):
                        if di == 0 and dj == 0:
                            continue
                        ni, nj = i0 + di, j0 + dj
                        if not (0 <= ni < rows and 0 <= nj < cols):
                            continue
                        neighbor_env = global_envrionment_map[ni, nj]
                        if current_env not in (1, 2) or neighbor_env not in (1, 2):
                            continue
                        if neighbor_env == current_env:
                            continue
                        normal_vec = global_normal_map[i0, j0]
                        direction_vec = np.array([ni - i0, nj - j0])
                        angle = np.arctan2(direction_vec[1], direction_vec[0])
                        _, pitch_raw, roll_raw = get_euler_from_normal(normal_vec, angle)
                        pitch, roll = abs(pitch_raw), abs(roll_raw)
                        elevation_diff = abs(global_mean_map[i0, j0] - global_mean_map[ni, nj])
                        cross_risk = compute_cross_domain_risk(pitch, roll, elevation_diff)
                        
                        if cross_risk < best_cost:
                            best_cost, best_cross = cross_risk, (ni, nj)
                cross_pt = best_cross
                # 模拟行进到真正的跨域点
                i0, j0 = current
                current_env = global_envrionment_map[i0, j0]
                if current_env==2:
                    reached, cross_path, _, maps = navigate_segment_with_cross_event(
                        current, candidate_cross,global_mean_map, global_slope_map, global_roughness_map,
                global_envrionment_map, global_traversability_map,
                global_frozen_map, global_normal_map,
                        use_weighted=True,
                        use_cross_domain=False,
                        use_huanjing=True
                    )
                    if reached:
                        if cross_path[0] != current:
                            cross_path = cross_path[::-1]
                        for grid in cross_path[1:]:
                            path_list.append(grid)
                    path_list.append(cross_pt)
                    return False, path_list, cross_pt, {
                    "mean_map": global_mean_map,
                    "slope_map": global_slope_map,
                    "rough_map": global_roughness_map,
                    "env_map": global_envrionment_map,
                    "trav_map": global_traversability_map,
                    "normal_map": global_normal_map,
                    "frozen": global_frozen_map
                }
                elif current_env==1:
                    reached, cross_path, _, maps = navigate_segment_with_cross_event(
                        current, cross_pt,global_mean_map, global_slope_map, global_roughness_map,
                global_envrionment_map, global_traversability_map,
                global_frozen_map, global_normal_map,
                        use_weighted=True,
                        use_cross_domain=False,
                        use_huanjing=True
                    )
                    if reached:
                        if cross_path[0] != current:
                            cross_path = cross_path[::-1]
                        for grid in cross_path[1:]:
                            path_list.append(grid)
                    path_list.append(candidate_cross)
                    return False, path_list, candidate_cross, {
                    "mean_map": global_mean_map,
                    "slope_map": global_slope_map,
                    "rough_map": global_roughness_map,
                    "env_map": global_envrionment_map,
                    "trav_map": global_traversability_map,
                    "normal_map": global_normal_map,
                    "frozen": global_frozen_map
                }

                else:
                    break
                # is_valid, cross_path = try_virtual_goal_path(


        # 7. 正常前进一步
        current = next_grid
        path_list.append(current)
    return True, path_list, None, {
                    "mean_map": global_mean_map,
                    "slope_map": global_slope_map,
                    "rough_map": global_roughness_map,
                    "env_map": global_envrionment_map,
                    "trav_map": global_traversability_map,
                    "normal_map": global_normal_map,
                    "frozen": global_frozen_map
                }

# 第一步：加载本地点云
file_path = "20250330.xyz"
xyz_points = np.loadtxt(file_path)
min_x = np.min(xyz_points[:, 0])
min_y = np.min(xyz_points[:, 1])
max_x = np.max(xyz_points[:, 0])
max_y = np.max(xyz_points[:, 1])
resolution = 0.4
# 构建栅格函数（保持不变）
large_size = 0.8
small_size = 0.4
local_range = 5
# 1. 提取地图边界范围

# 3. 构建 X、Y 方向的栅格坐标轴
large_grid_x = np.arange(min_x, max_x + large_size, large_size)
large_grid_y = np.arange(min_y, max_y + large_size, large_size)
small_grid_x = np.arange(min_x, max_x + small_size, small_size)
small_grid_y = np.arange(min_y, max_y + small_size, small_size)

# 4. 构建 meshgrid 网格中心点坐标对（可用于可视化、点映射）
large_grid = np.array(np.meshgrid(large_grid_x, large_grid_y)).T.reshape(-1, 2)
small_grid = np.array(np.meshgrid(small_grid_x, small_grid_y)).T.reshape(-1, 2)

# 5. 获取主地图尺寸（X方向列数，Y方向行数）
num_x = int(np.ceil((max_x - min_x) / resolution)) + 1
num_y = int(np.ceil((max_y - min_y) / resolution)) + 1

# # 6. 初始化全局地图（NaN 或零填充，待写入）
# global_mean_map = np.full((num_x, num_y), np.nan)
# global_slope_map = np.full((num_x, num_y), np.nan)        # 坡度地图
# global_normal_map = np.zeros((num_x, num_y, 3))           # 法向量地图 (x, y, z)
# global_roughness_map = np.full((num_x, num_y), np.nan)    # 粗糙度地图
# global_traversability_map = np.full((num_x, num_y), np.nan)  # 通行性代价地图
# global_envrionment_map = np.full((num_x, num_y), np.nan)   # 环境地图
# global_frozen_map = np.zeros_like(global_envrionment_map, dtype=bool)
# global_water_edge_map = np.zeros((num_x, num_y), dtype=bool)







ENABLE_BENCHMARK = True
GRID_RES = 0.4
TARGET_DIST_M = 40.0
TIMEOUT_S = 100.0
N_TRIALS = 200


def _bounds_from_points(xyz):
    xmin, xmax = float(xyz[:,0].min()), float(xyz[:,0].max())
    ymin, ymax = float(xyz[:,1].min()), float(xyz[:,1].max())
    return xmin, xmax, ymin, ymax

def sample_valid_start_goal(xyz_points, desired_dist=TARGET_DIST_M, max_tries=200, local_check_radius=5.0):
    Point = namedtuple("Point", ["x","y"])
    xmin, xmax, ymin, ymax = _bounds_from_points(xyz_points)
    for _ in range(max_tries):
        sx, sy = random.uniform(xmin, xmax), random.uniform(ymin, ymax)
        start_point = Point(sx, sy)
        theta = random.uniform(-math.pi, math.pi)
        gx, gy = sx + desired_dist * math.cos(theta), sy + desired_dist * math.sin(theta)
        if not (xmin <= gx <= xmax and ymin <= gy <= ymax):
            continue
        goal_point = Point(gx, gy)
        return start_point, goal_point
    return None, None

def path_length_in_grids(path):
    return max(0, len(path)-1) if path else 0

def benchmark_dstar_pairs(xyz_points, enable=ENABLE_BENCHMARK):
    if not enable:
        print("[Benchmark] 关闭批量测试")
        return [], None

    results = []
    # >>> N_TRIALS×2 行，每行 22 列（跟你的 calculate_temp_target 口径一致）
    temp_target_5 = [[None]*22 for _ in range(N_TRIALS * 3)]

    random.seed(42)
    collected = 0
    trial_id = 0
    fail = {
        "sample_fail": 0,         # 起终点采样失败（含越界/未返回）
        "mapping_fail": 0,        # run_sgp_mapping 异常
        "validity_fail": 0,       # is_point_valid 判定不通过
        "trad_exc": 0,            # 传统 D* 调用异常
        "trad_timeout_or_unreach": 0,
        "weighted_exc": 0,        # 加权 D* 调用异常
        "weighted_timeout_or_unreach": 0,
    }

    while collected < N_TRIALS:
        trial_id += 1
        print(f"\n=== 测试 {trial_id} / {N_TRIALS} ===")
        start_point, goal_point = sample_valid_start_goal(xyz_points)
        if start_point is None:
            fail["sample_fail"] += 1
            print("[Skip] sample_valid_start_goal 未采到有效起终点")
            continue
        
        print("[Skip] sample_valid_start_goal 采到有效起终点")
        # ---- 初始化全局地图 ----
        global_mean_map = np.full((num_x, num_y), np.nan)
        global_slope_map = np.full((num_x, num_y), np.nan)
        global_normal_map = np.zeros((num_x, num_y, 3))
        global_roughness_map = np.full((num_x, num_y), np.nan)
        global_traversability_map = np.full((num_x, num_y), np.nan)
        global_envrionment_map = np.full((num_x, num_y), np.nan)
        global_frozen_map = np.zeros_like(global_envrionment_map, dtype=bool)
        global_water_edge_map = np.zeros((num_x, num_y), dtype=bool)
        
        print("[Skip] sample_valid_start_goal 开始检测")
        print("[Info] 局部建图完成，开始有效性检测")
        try:
            ok_start = is_point_valid(
                start_point, 
                global_mean_map, global_slope_map, global_roughness_map,
                global_envrionment_map, global_traversability_map,
                global_frozen_map, global_normal_map
            )
            ok_goal  = is_point_valid(
                goal_point,  
                global_mean_map, global_slope_map, global_roughness_map,
                global_envrionment_map, global_traversability_map,
                global_frozen_map, global_normal_map
            )
            if (not ok_start) or (not ok_goal):
                fail["validity_fail"] += 1
                print(f"[Skip] validity_fail: ok_start={ok_start}, ok_goal={ok_goal}")
                continue
        except Exception as e:
            fail["validity_fail"] += 1
            # 如需定位栈，可用 traceback
            # import traceback; traceback.print_exc()
            print(f"[Skip] validity_fail(exception): {e}")
            continue

        print("[Pass] 起点/终点有效")
        initial_start_grid = world_to_grid(start_point.x, start_point.y)
        initial_goal_grid  = world_to_grid(goal_point.x, goal_point.y)
        
        full_path_indices = []
        current = initial_start_grid
        t_start = time.time()  # 记录整个路径规划的起始时间
        try:
            t0 = time.time()
            t_start = t0                  # 或者单独写 t_start = time.time()
            reached = (current == initial_goal_grid)
            # 确保有这个容器
            # full_path_indices = []  # 若前面未定义，放开这一行

            while current != initial_goal_grid:
                # 如果运行时间超过 60 秒则强制退出
                if time.time() - t_start > 100:
                    print("⏰ 规划超时（>60s），强制退出循环！")
                    reached = False
                    break

                reached, seg, cross_pt, maps = navigate_segment_with_cross_event(
                    current, initial_goal_grid,
                    global_mean_map, global_slope_map, global_roughness_map,
                    global_envrionment_map, global_traversability_map,
                    global_frozen_map, global_normal_map,
                    use_weighted=True,use_cross_domain=True,use_huanjing=True
                )
                
                global_envrionment_map= maps["env_map"]
                global_traversability_map= maps["trav_map"]
                global_mean_map= maps["mean_map"]
                global_normal_map= maps["normal_map"]
                global_slope_map= maps["slope_map"]
                global_frozen_map= maps["frozen"]
                # 合并本段，去掉 seg[0] 重复点
                if seg:
                    full_path_indices += seg[0:]  # ← 关键修正

                if reached:
                    print("✅ 成功到达终点！")
                    break

                # 跨域动作（下水或上岸）
                print(f"🚧 在格点 {cross_pt} 触发跨域，执行动作…")
                current = cross_pt
                print("上一段结束，new current =", cross_pt)
                print("下一段开始，start current =", current)

            t1 = time.time()
        except Exception as e:
            print(f"❗规划异常：{e}")
            continue

        elapsed_trad = t1 - t0
        # 若已在循环里做了 60s 超时，这里可只保留 reached 判断；或保持一致用同一阈值
        if (not reached) or (elapsed_trad > TIMEOUT_S):
            continue
        
        path_trad_np = np.asarray(full_path_indices, dtype=int)
        
        global_envrionment_map= maps["env_map"]
        global_traversability_map= maps["trav_map"]
        global_mean_map= maps["mean_map"]
        global_normal_map= maps["normal_map"]
        
        # 行号：偶数=传统，奇数=加权
        base_row = collected * 3
        temp_target_5 = calculate_temp_target(
            temp_target_5,              # 第一参数：容器
            base_row,                   # 第二参数：当前行索引 c
            path_trad_np,               # 之后按你的签名依次传
            global_envrionment_map,
            global_traversability_map,
            global_mean_map,
            global_normal_map,
            initial_start_grid,
            initial_goal_grid,
            elapsed_trad
        )        


        # ---- 初始化全局地图 ----
        global_mean_map = np.full((num_x, num_y), np.nan)
        global_slope_map = np.full((num_x, num_y), np.nan)
        global_normal_map = np.zeros((num_x, num_y, 3))
        global_roughness_map = np.full((num_x, num_y), np.nan)
        global_traversability_map = np.full((num_x, num_y), np.nan)
        global_envrionment_map = np.full((num_x, num_y), np.nan)
        global_frozen_map = np.zeros_like(global_envrionment_map, dtype=bool)
        global_water_edge_map = np.zeros((num_x, num_y), dtype=bool)
        result1 =run_sgp_mapping(start_point.x, start_point.y)
        xx_grid, yy_grid, mean_grid, slope_grid, var_grid, flatness_map, step_height_map, semantic_map, trav_map, grad_mean,rmse,r2,nll_mean,training_time, infer_time,mem_peak,N_local  = result1
        update_global_maps_from_sgp(xx_grid, yy_grid, mean_grid, slope_grid, var_grid, semantic_map, trav_map, grad_mean,global_mean_map,global_slope_map,global_roughness_map,global_envrionment_map,global_traversability_map,global_frozen_map,global_normal_map)

        # ===== 1) 传统 D* Lite =====
        try:
            t0 = time.time()
            reached_trad, path_traditional, _,maps = navigate_segment_with_cross_event(
                initial_start_grid, initial_goal_grid,global_mean_map, global_slope_map, global_roughness_map,
                global_envrionment_map, global_traversability_map,
                global_frozen_map, global_normal_map,
                use_weighted=False, use_cross_domain=False, use_huanjing=False)
            t1 = time.time()
        except Exception:
            continue
        elapsed_trad = t1 - t0
        if (not reached_trad) or (elapsed_trad > TIMEOUT_S):
            continue

        # 保证传入 numpy (N,2) 整型索引
        
        path_trad_np = np.asarray(path_traditional, dtype=int)
        
        global_envrionment_map= maps["env_map"]
        global_traversability_map= maps["trav_map"]
        global_mean_map= maps["mean_map"]
        global_normal_map= maps["normal_map"]
        
        # 行号：偶数=传统，奇数=加权
        temp_target_5 = calculate_temp_target(
            temp_target_5,              # 第一参数：容器
            base_row + 1,                   # 第二参数：当前行索引 c
            path_trad_np,               # 之后按你的签名依次传
            global_envrionment_map,
            global_traversability_map,
            global_mean_map,
            global_normal_map,
            initial_start_grid,
            initial_goal_grid,
            elapsed_trad
        )
        
        # ---- 初始化全局地图 ----
        global_mean_map = np.full((num_x, num_y), np.nan)
        global_slope_map = np.full((num_x, num_y), np.nan)
        global_normal_map = np.zeros((num_x, num_y, 3))
        global_roughness_map = np.full((num_x, num_y), np.nan)
        global_traversability_map = np.full((num_x, num_y), np.nan)
        global_envrionment_map = np.full((num_x, num_y), np.nan)
        global_frozen_map = np.zeros_like(global_envrionment_map, dtype=bool)
        global_water_edge_map = np.zeros((num_x, num_y), dtype=bool)
        # ===== 2) 加权 D* Lite（不跨域）=====
        
        result1 =run_sgp_mapping(start_point.x, start_point.y)
        xx_grid, yy_grid, mean_grid, slope_grid, var_grid, flatness_map, step_height_map, semantic_map, trav_map, grad_mean,rmse,r2,nll_mean,training_time, infer_time,mem_peak,N_local  = result1
        update_global_maps_from_sgp(xx_grid, yy_grid, mean_grid, slope_grid, var_grid, semantic_map, trav_map, grad_mean,global_mean_map,global_slope_map,global_roughness_map,global_envrionment_map,global_traversability_map,global_frozen_map,global_normal_map)

        try:
            t0 = time.time()
            reached_w, path_weighted, _,maps1 = navigate_segment_with_cross_event(
                initial_start_grid, initial_goal_grid,global_mean_map, global_slope_map, global_roughness_map,
                global_envrionment_map, global_traversability_map,
                global_frozen_map, global_normal_map,
                use_weighted=True, use_cross_domain=False, use_huanjing=False)
            t1 = time.time()
        except Exception:
            continue
        elapsed_w = t1 - t0
        if (not reached_w) or (elapsed_w > TIMEOUT_S):
            continue

        path_w_np = np.asarray(path_weighted, dtype=int)
        
        global_envrionment_map= maps1["env_map"]
        global_traversability_map= maps1["trav_map"]
        global_mean_map= maps1["mean_map"]
        global_normal_map= maps1["normal_map"]
        
        temp_target_5 = calculate_temp_target(
            temp_target_5,
            base_row + 2,               # 同一次试验的第二行
            path_w_np,
            global_envrionment_map,
            global_traversability_map,
            global_mean_map,
            global_normal_map,
            initial_start_grid,
            initial_goal_grid,
            elapsed_w
        )

        results.append({
            "trial_id": trial_id,
            "start_x": start_point.x, "start_y": start_point.y,
            "goal_x": goal_point.x, "goal_y": goal_point.y,
            "trad_time": elapsed_trad, "trad_len": path_length_in_grids(path_traditional),
            "weighted_time": elapsed_w, "weighted_len": path_length_in_grids(path_weighted)
        })
        collected += 1
        print(f"  ✅ 有效样本 {collected}/{N_TRIALS}: trad {elapsed_trad:.2f}s, weighted {elapsed_w:.2f}s")

    # —— 结果落盘（结构化统计 + 原始计算矩阵）——
    # —— 结果落盘（结构化统计 + 原始计算矩阵）——
    # if results:
    #     # 假设你已经有 results 与 temp_target_5
    #     # 直接用 temp_target_5 做完整分析
    #     stats = analyze_from_temp_target(temp_target_5, save_fig=True, fig_path="benchmark_iqr.png")

    #     out_csv = "benchmark_50pairs.csv"
    #     with open(out_csv, "w", newline="", encoding="utf-8") as f:
    #         writer = csv.DictWriter(f, fieldnames=list(results[0].keys()))
    #         writer.writeheader()
    #         writer.writerows(results)
    #     print(f"[Benchmark] 统计已写入：{os.path.abspath(out_csv)}")

    # ==== 追加：导出 temp_target_5 到 CSV + NPY ====


    stats_df = analyze_three_algos(temp_target_5, save_prefix="uatc_benchmark")
    N_ALGOS = 3
    ALGO_NAMES = ["CDA-D*Lite", "T-D*Lite", "UATC-D*Lite"]

    t5_csv = "temp_target_5.csv"
    headers = [
        "row_index", "algo",
        "avg_pitch", "avg_roll", "avg_travel", "avg_z_diff",   # 2,3,4,5
        "path_len", "travel_sum", "pitch_sum", "roll_sum",     # 7,8,9,10
        "up_pitch", "up_roll", "down_pitch", "down_roll",      # 11,12,13,14（可为标量或列表）
        "roughness_sum",                                       # 15
        "z_diff_sum", "z_diff_up", "z_diff_down",              # 16,17,18（可为标量或列表）
        "num_transitions",                                     # 20
        "time",                                                # 21
        "path_json"                                            # 19
    ]

    def _to_json_if_list(x):
        # 兼容标量 / 列表 / ndarray：列表或数组转 JSON，标量原样
        if isinstance(x, (list, tuple, np.ndarray)):
            return json.dumps(np.asarray(x).tolist(), ensure_ascii=False)
        return x

    with open(t5_csv, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=headers)
        w.writeheader()

        for idx, row in enumerate(temp_target_5):
            # 仅导出“有路径”的有效行（你用 row[19] 存的 path）
            if not row or len(row) < 22 or row[19] is None:
                continue

            try:
                path_arr = np.asarray(row[19], dtype=int)  # (N,2)
                algo = ALGO_NAMES[idx % N_ALGOS]           # 0/1/2 -> 三个算法顺序

                rec = {
                    "row_index": idx,
                    "algo": algo,
                    "avg_pitch": row[2],
                    "avg_roll": row[3],
                    "avg_travel": row[4],
                    "avg_z_diff": row[5],
                    "path_len": row[7],
                    "travel_sum": row[8],
                    "pitch_sum": row[9],
                    "roll_sum": row[10],

                    # 下面这些字段如果你按我之前建议改成“列表收集”，也能被自动转 JSON
                    "up_pitch": _to_json_if_list(row[11]),
                    "up_roll": _to_json_if_list(row[12]),
                    "down_pitch": _to_json_if_list(row[13]),
                    "down_roll": _to_json_if_list(row[14]),

                    "roughness_sum": row[15],
                    "z_diff_sum": row[16],
                    "z_diff_up": _to_json_if_list(row[17]),
                    "z_diff_down": _to_json_if_list(row[18]),

                    "num_transitions": row[20],
                    "time": row[21],
                    "path_json": json.dumps(path_arr.tolist(), ensure_ascii=False),
                }
                w.writerow(rec)

            except Exception as e:
                print(f"[Benchmark] 跳过第 {idx} 行（写入异常）：{e}")

    print(f"[Benchmark] temp_target_5 已写入：{os.path.abspath(t5_csv)}")


    # # 可选：把原始对象矩阵也保存一份，便于后续 Python 直接读取深入分析
    # try:
    #     np.save("temp_target_5.npy", np.array(temp_target_5, dtype=object), allow_pickle=True)
    #     print(f"[Benchmark] temp_target_5.npy 已写入：{os.path.abspath('temp_target_5.npy')}")
    # except Exception as e:
    #     print(f"[Benchmark] 保存 temp_target_5.npy 失败：{e}")


    # return results, temp_target_5







results = benchmark_dstar_pairs(xyz_points, enable=True)


exit()


# 定义起点和终点
# start_point = Point(250, 205)
# goal_point = Point(250, 195)

# start_point = Point(250, 120)
# goal_point = Point(260, 120)
start_point = Point(205, 160)
goal_point = Point(220, 140)

# start_point = Point(200, 150)
# goal_point = Point(240, 150)

# start_point = Point(170, 200)
# goal_point = Point(190, 185)
# x_fixed = 220.0
# y_start, y_end, dy = 140.0, 180.0, 0.4

# # 构建 y 序列，确保恰好 100 步
# y_steps = np.arange(y_start, y_end + 1e-9, dy)[:100]  # 防浮点误差
# traj_xy = np.column_stack([np.full_like(y_steps, x_fixed), y_steps]).astype(np.float32)

x_start, x_end = 210, 220
y_fixed = 155.0  # 水陆边界附近 155
x_steps = np.arange(x_start, x_end + 1e-6, 0.4)[:100]
traj_xy = np.column_stack([x_steps, np.full_like(x_steps, y_fixed)]).astype(np.float32)

print(f"trajectory shape: {traj_xy.shape}, first={traj_xy[0]}, last={traj_xy[-1]}")
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
path_xy_torch = torch.tensor(traj_xy, dtype=torch.float32, device=device)

results_step = []
USE_M = 128        # None 表示维持你现在的 “<=500 上限”；也可设 256
USE_MODE = "KM"    # "UNIF" | "KM" | "PB"
prev_mean_grid = None  # 预留：后续如要加“帧间重叠RMSE”可用


global_mean_map = np.full((num_x, num_y), np.nan)
global_slope_map = np.full((num_x, num_y), np.nan)        # 坡度地图
global_normal_map = np.zeros((num_x, num_y, 3))           # 法向量地图 (x, y, z)
global_roughness_map = np.full((num_x, num_y), np.nan)    # 粗糙度地图
global_traversability_map = np.full((num_x, num_y), np.nan)  # 通行性代价地图
global_envrionment_map = np.full((num_x, num_y), np.nan)   # 环境地图
global_frozen_map = np.zeros_like(global_envrionment_map, dtype=bool)
global_water_edge_map = np.zeros((num_x, num_y), dtype=bool)



# ==== 4) 沿路径逐步调用你的 run_sgp_mapping ====
for k, (x0, y0) in enumerate(traj_xy):
    result = run_sgp_mapping(
        float(x0), float(y0),
        local_range=5,
        M=USE_M,
        inducing_mode=USE_MODE,
        path_xy=(path_xy_torch if USE_MODE=="PB" else None),  # PB 才需要；KM/UNIF 传 None
        step_idx=k,          # ← 关键：当前步索引
        heavy_every=5,       # ← 每5步“重训”
        iters_heavy=3,       # ← 重训3次
        iters_light=1,       # ← 其余1次
        use_warm_start=True, # ← 开启复用参数
        N_cap=1000            # ← 密集区域限点
    )
    (xx_grid, yy_grid, mean_grid, slope_grid, var_grid,
     flatness_map, step_height_map, semantic_map, trav_map,
     grad_mean, rmse, r2, nll_mean, training_time, infer_time, mem_peak,N_local) = result
    update_global_maps_from_sgp(xx_grid, yy_grid, mean_grid, slope_grid, var_grid, semantic_map, trav_map, grad_mean,global_mean_map,global_slope_map,global_roughness_map,global_envrionment_map,global_traversability_map,global_frozen_map,global_normal_map)

    results_step.append({
        "step": k,
        "x": float(x0), "y": float(y0),
        "rmse": float(rmse),
        "r2": float(r2),
        "nll": float(nll_mean),
        "t_train_ms": training_time * 1000.0,
        "t_infer_ms": infer_time * 1000.0,
        "mem_MB": (None if mem_peak is None else float(mem_peak)),
        "N_local": N_local,
        "M_used": (16 if USE_M is not None else min(500, N_local)),
        "M_over_N": ( (16 / N_local) if USE_M is not None and N_local>0 else float("nan") )
    })

# # ==== 5) 查看前几步 + 总步数 ====
# for row in results_step[:5]:
#     print(row)
# print(f"... total steps: {len(results_step)}")

# ==== 6) 路径整体均值（论文里可直接引用） ====
def avg(key):
    vals = [r[key] for r in results_step if (r[key] is not None) and (not np.isnan(r[key]))]
    return float(np.mean(vals)) if len(vals) else float("nan")

rmse_mean = avg("rmse");  r2_mean = avg("r2");  nll_m = avg("nll")
ttr_m = avg("t_train_ms"); tin_m = avg("t_infer_ms"); mem_m = avg("mem_MB")
def median(key): 
    arr = [r[key] for r in results_step if r[key] is not None and not np.isnan(r[key])]
    return float(np.median(arr)) if arr else float("nan")

print(f"Median N_local={median('N_local'):.0f},  Median M/N={median('M_over_N'):.3f}")

print(f"[Path (220,140)->(220,180), 100 steps, dy=0.4] "
      f"RMSE={rmse_mean:.4f}, R2={r2_mean:.3f}, NLL={nll_m:.4f}, "
      f"Train={ttr_m:.1f}ms, Infer={tin_m:.1f}ms, MEM={mem_m if mem_m==mem_m else '—'} MB")

show_global_elevation_uncertainty(global_mean_map, global_roughness_map, save_path="SGP_global_maps.png")

exit()


if not is_point_valid(start_point,global_mean_map,global_slope_map,global_roughness_map,global_envrionment_map,global_traversability_map,global_frozen_map,global_normal_map) or not is_point_valid(goal_point,global_mean_map,global_slope_map,global_roughness_map,global_envrionment_map,global_traversability_map,global_frozen_map,global_normal_map):
    raise ValueError("起点或终点无效，规划终止。")
    sys.exit(1)  # ⚠️ 终止整个程序运行
print("初始规划的路径1：")
# 6. 初始化全局地图（NaN 或零填充，待写入）

global_mean_map = np.full((num_x, num_y), np.nan)
global_slope_map = np.full((num_x, num_y), np.nan)        # 坡度地图
global_normal_map = np.zeros((num_x, num_y, 3))           # 法向量地图 (x, y, z)
global_roughness_map = np.full((num_x, num_y), np.nan)    # 粗糙度地图
global_traversability_map = np.full((num_x, num_y), np.nan)  # 通行性代价地图
global_envrionment_map = np.full((num_x, num_y), np.nan)   # 环境地图
global_frozen_map = np.zeros_like(global_envrionment_map, dtype=bool)
global_water_edge_map = np.zeros((num_x, num_y), dtype=bool)


# 起点附近局部建图（替代初始全局建图）
initial_xyz = xyz_points[np.linalg.norm(xyz_points[:, :2] - np.array([start_point.x, start_point.y]), axis=1) <= 5]
result =run_sgp_mapping(start_point.x, start_point.y)
xx_grid, yy_grid, mean_grid, slope_grid, var_grid, flatness_map, step_height_map, semantic_map, trav_map, grad_mean,rmse,r2,nll_mean,training_time, infer_time,mem_peak,N_local  = result
print(f"NLL: {nll_mean:.4f} | Train: {training_time*1000:.1f} ms | Infer: {infer_time*1000:.1f} ms | MEM: {mem_peak} MB")

update_global_maps_from_sgp(xx_grid, yy_grid, mean_grid, slope_grid, var_grid, semantic_map, trav_map, grad_mean,global_mean_map,global_slope_map,global_roughness_map,global_envrionment_map,global_traversability_map,global_frozen_map,global_normal_map)
# 创建 D* Lite 规划器实例
initial_start_grid=world_to_grid(start_point.x, start_point.y)
initial_goal_grid=world_to_grid(goal_point.x, goal_point.y)

temp_target_5 = [[None]*22 for _ in range(3)]

start_time = time.time()
# 1. 纯传统 D* Lite（不加权、不做跨域）  
reached, path_traditional, _, maps = navigate_segment_with_cross_event(
    initial_start_grid, initial_goal_grid, global_mean_map, global_slope_map, global_roughness_map,
                global_envrionment_map, global_traversability_map,
                global_frozen_map, global_normal_map,
    use_weighted=False,
    use_cross_domain=False,
    use_huanjing=False
)
end_time = time.time()
elapsed_time = end_time - start_time

global_envrionment_map= maps["env_map"]
global_traversability_map= maps["trav_map"]
global_mean_map= maps["mean_map"]
global_normal_map= maps["normal_map"]


temp_target_5 =calculate_temp_target(
        temp_target_5, 0, path_traditional,
        global_envrionment_map,global_traversability_map, global_mean_map, global_normal_map,
        initial_start_grid, initial_goal_grid,
         elapsed_time)

print("🎯 path_traditional成功到达终点！任务完成。")
        # ✅ 输出最终路径的栅格坐标
print("🧩 path_traditional最终路径为（栅格坐标系）：")
for grid_point in path_traditional:
    print(grid_point)  

mean_rmse = np.mean(rmse_list)
std_rmse  = np.std(rmse_list)
mean_r2   = np.mean(r2_list)
std_r2    = np.std(r2_list)

print("========== SGP 建图总体性能 ==========")
print(f"平均 RMSE = {mean_rmse:.4f} ± {std_rmse:.4f}")
print(f"平均 R²  = {mean_r2:.4f} ± {std_r2:.4f}")

# 2. 改进 D* Lite（加权代价，但不做跨域） 
#  
# 6. 初始化全局地图（NaN 或零填充，待写入）
global_mean_map = np.full((num_x, num_y), np.nan)
global_slope_map = np.full((num_x, num_y), np.nan)        # 坡度地图
global_normal_map = np.zeros((num_x, num_y, 3))           # 法向量地图 (x, y, z)
global_roughness_map = np.full((num_x, num_y), np.nan)    # 粗糙度地图
global_traversability_map = np.full((num_x, num_y), np.nan)  # 通行性代价地图
global_envrionment_map = np.full((num_x, num_y), np.nan)   # 环境地图
global_frozen_map = np.zeros_like(global_envrionment_map, dtype=bool)
global_water_edge_map = np.zeros((num_x, num_y), dtype=bool)

initial_xyz = xyz_points[np.linalg.norm(xyz_points[:, :2] - np.array([start_point.x, start_point.y]), axis=1) <= 5]
result =run_sgp_mapping(start_point.x, start_point.y)
xx_grid, yy_grid, mean_grid, slope_grid, var_grid, flatness_map, step_height_map, semantic_map, trav_map, grad_mean,rmse,r2,nll_mean,training_time, infer_time,mem_peak,N_local  = result
update_global_maps_from_sgp(xx_grid, yy_grid, mean_grid, slope_grid, var_grid, semantic_map, trav_map, grad_mean,global_mean_map,global_slope_map,global_roughness_map,global_envrionment_map,global_traversability_map,global_frozen_map,global_normal_map)

start_time = time.time()
reached, path_weighted_only, _, maps = navigate_segment_with_cross_event(
    initial_start_grid, initial_goal_grid, global_mean_map, global_slope_map, global_roughness_map,
                global_envrionment_map, global_traversability_map,
                global_frozen_map, global_normal_map,
    use_weighted=True,
    use_cross_domain=False,
    use_huanjing=False
)

end_time = time.time()
elapsed_time1 = end_time - start_time

global_envrionment_map= maps["env_map"]
global_traversability_map= maps["trav_map"]
global_mean_map= maps["mean_map"]
global_normal_map= maps["normal_map"]

temp_target_5 =calculate_temp_target(
        temp_target_5, 1, path_weighted_only,
        global_envrionment_map,global_traversability_map, global_mean_map, global_normal_map,
        initial_start_grid, initial_goal_grid,
         elapsed_time1)


print("🎯 path_weighted_only成功到达终点！任务完成。")
        # ✅ 输出最终路径的栅格坐标
print("🧩 path_weighted_only最终路径为（栅格坐标系）：")
for grid_point in path_weighted_only:
    print(grid_point)
# 6. 初始化全局地图（NaN 或零填充，待写入）

global_mean_map = np.full((num_x, num_y), np.nan)
global_slope_map = np.full((num_x, num_y), np.nan)        # 坡度地图
global_normal_map = np.zeros((num_x, num_y, 3))           # 法向量地图 (x, y, z)
global_roughness_map = np.full((num_x, num_y), np.nan)    # 粗糙度地图
global_traversability_map = np.full((num_x, num_y), np.nan)  # 通行性代价地图
global_envrionment_map = np.full((num_x, num_y), np.nan)   # 环境地图
global_frozen_map = np.zeros_like(global_envrionment_map, dtype=bool)
global_water_edge_map = np.zeros((num_x, num_y), dtype=bool)

# 起点附近局部建图（替代初始全局建图）
initial_xyz = xyz_points[np.linalg.norm(xyz_points[:, :2] - np.array([start_point.x, start_point.y]), axis=1) <= 5]
result =run_sgp_mapping(start_point.x, start_point.y)
xx_grid, yy_grid, mean_grid, slope_grid, var_grid, flatness_map, step_height_map, semantic_map, trav_map, grad_mea,rmse,r2,nll_mean,training_time, infer_time,mem_peak,N_local  = result
update_global_maps_from_sgp(xx_grid, yy_grid, mean_grid, slope_grid, var_grid, semantic_map, trav_map, grad_mean,global_mean_map,global_slope_map,global_roughness_map,global_envrionment_map,global_traversability_map,global_frozen_map,global_normal_map)

# —— 主流程：支持多次跨域 —— 
full_path_indices = []
current = initial_start_grid
start2_time = time.time()

while current != initial_goal_grid:
    reached, seg, cross_pt,maps = navigate_segment_with_cross_event(current, initial_goal_grid, global_mean_map, global_slope_map, global_roughness_map,
                global_envrionment_map, global_traversability_map,
                global_frozen_map, global_normal_map,use_weighted=True,use_cross_domain=True,use_huanjing=True)
    # 合并本段（去掉 seg[0] 重复）
    full_path_indices += seg[0:]

    if reached:
        print("✅ 成功到达终点！")
        break

    # 跨域动作（下水或上岸）
    print(f"🚧 在格点 {cross_pt} 触发跨域，执行动作…")
    current = cross_pt
    print("上一段结束，new current =", cross_pt)
    print("下一段开始，start current =", current)
    # water_control.enter_water()  或 exit_water()


end_time = time.time()
elapsed_time2 = end_time - start2_time
global_envrionment_map= maps["env_map"]
global_traversability_map= maps["trav_map"]
global_mean_map= maps["mean_map"]
global_normal_map= maps["normal_map"]
temp_target_5 =calculate_temp_target(
        temp_target_5, 2, full_path_indices,
        global_envrionment_map,global_traversability_map, global_mean_map, global_normal_map,
        initial_start_grid, initial_goal_grid,
         elapsed_time2)




# 假设 temp_target_5 是一个 list of list，形状为 (M, 22)
# 请根据你的实际列含义替换下面的列名
column_names = [
    "cx","cy",
    "start_i","start_j",
    "goal_i","goal_j",
    "unused7","path_len","unused9",
    "sum_pitch","sum_roll",
    "up_pitch","up_roll","down_pitch","down_roll",
    "roughness_sum","z_diff_sum","z_diff_up","z_diff_down",
    "raw_path","num_transitions","time"
]
df = pd.DataFrame(temp_target_5, columns=column_names)
df.to_csv("path_metrics.csv", index=False, encoding="utf-8-sig")





print("📍 完整路径格点序列：", full_path_indices)


for grid_point in path_traditional:
    if global_traversability_map[grid_point[0], grid_point[1]]>=1:
        global_traversability_map[grid_point[0], grid_point[1]]= 0.8

for grid_point in path_weighted_only:
    if global_traversability_map[grid_point[0], grid_point[1]]>=1:
        global_traversability_map[grid_point[0], grid_point[1]]= 0.8

for grid_point in full_path_indices:
    if global_traversability_map[grid_point[0], grid_point[1]]>=1:
        global_traversability_map[grid_point[0], grid_point[1]]= 0.8

water_edge_mask = extract_water_edge_from_semantic_map(
                        global_envrionment_map,
                        global_traversability_map
                    )
print("🎯 成功到达终点！任务完成。")
        # ✅ 输出最终路径的栅格坐标
print("🧩 最终路径为（栅格坐标系）：")
for grid_point in full_path_indices:
    print(grid_point)  
min_x = np.min(xyz_points[:, 0])
min_y = np.min(xyz_points[:, 1])
max_x = np.max(xyz_points[:, 0])
max_y = np.max(xyz_points[:, 1])



# print("water_edge_mask shape:", water_edge_mask.shape)
# print("water_edge_mask 有效像素数量：", np.sum(water_edge_mask))
start_grid = world_to_grid(start_point.x, start_point.y)
goal_grid = world_to_grid(goal_point.x, goal_point.y)
current_grid = full_path_indices[-1]

# visualize_path_local_water_edge(water_edge_mask, full_path_indices, min_x, min_y, resolution=0.4,start_grid=start_grid,goal_grid=goal_grid,current_grid=current_grid,virtual_goal=cross_pt 
#  )
# 起点终点是世界坐标，需要转栅格 ,virtual_path=path ,  virtual_goal=candidate_cross_grids


visualize_path_local_traversability1(
    trav_map=global_traversability_map,
    path_indices=full_path_indices,
    path_traditional=path_traditional,
    path_weighted_only=path_weighted_only,
    min_x=min_x,
    min_y=min_y,
    resolution=resolution,
    start_grid=start_grid,
    goal_grid=goal_grid,
    current_grid=current_grid,
    virtual_goal=cross_pt 

)

retrain_sgp_and_visualize_path(
    path_traditional=path_traditional,
    path_weighted_only=path_weighted_only,
    full_path_indices=full_path_indices,
    resolution=0.4,
    min_x=min_x,
    min_y=min_y,
    start_grid=initial_start_grid,
    goal_grid=initial_goal_grid
)


visualize_pointcloud_surface(full_path_indices=full_path_indices, resolution=0.4, min_x=min_x, min_y=min_y)